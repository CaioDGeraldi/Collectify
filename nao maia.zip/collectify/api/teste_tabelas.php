<?php
// api/teste_tabelas.php
require_once '../includes/conexao.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: text/html; charset=utf-8');

echo "<h2>🔍 Teste de Estrutura do Banco</h2>";

try {
    $pdo = getConnection();
    
    if (!$pdo) {
        echo "<p style='color: red;'>❌ Falha na conexão com o banco</p>";
        exit();
    }
    
    echo "<p style='color: green;'>✅ Conexão com banco estabelecida</p>";
    
    // 1. Verificar tabela COLEÇÕES
    echo "<h3>1. Tabela 'colecoes':</h3>";
    try {
        $stmt = $pdo->query("DESCRIBE colecoes");
        $colunas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<table border='1'>";
        echo "<tr><th>Campo</th><th>Tipo</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
        foreach ($colunas as $coluna) {
            echo "<tr>";
            echo "<td>{$coluna['Field']}</td>";
            echo "<td>{$coluna['Type']}</td>";
            echo "<td>{$coluna['Null']}</td>";
            echo "<td>{$coluna['Key']}</td>";
            echo "<td>{$coluna['Default']}</td>";
            echo "<td>{$coluna['Extra']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ Erro ao descrever colecoes: " . $e->getMessage() . "</p>";
    }
    
    // 2. Verificar tabela ITENS_COLECAO
    echo "<h3>2. Tabela 'itens_colecao':</h3>";
    try {
        $stmt = $pdo->query("DESCRIBE itens_colecao");
        $colunas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (count($colunas) > 0) {
            echo "<table border='1'>";
            echo "<tr><th>Campo</th><th>Tipo</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
            foreach ($colunas as $coluna) {
                echo "<tr>";
                echo "<td>{$coluna['Field']}</td>";
                echo "<td>{$coluna['Type']}</td>";
                echo "<td>{$coluna['Null']}</td>";
                echo "<td>{$coluna['Key']}</td>";
                echo "<td>{$coluna['Default']}</td>";
                echo "<td>{$coluna['Extra']}</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p style='color: orange;'>⚠️ Tabela itens_colecao não existe ou está vazia</p>";
        }
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ Erro ao descrever itens_colecao: " . $e->getMessage() . "</p>";
    }
    
    // 3. Verificar se a tabela existe
    echo "<h3>3. Verificação de existência:</h3>";
    $tabelas = ['colecoes', 'itens_colecao', 'itens'];
    
    foreach ($tabelas as $tabela) {
        $stmt = $pdo->query("SHOW TABLES LIKE '$tabela'");
        if ($stmt->rowCount() > 0) {
            echo "<p style='color: green;'>✅ Tabela '$tabela' existe</p>";
        } else {
            echo "<p style='color: red;'>❌ Tabela '$tabela' NÃO existe</p>";
        }
    }
    
    // 4. Testar consulta que está dando erro
    echo "<h3>4. Teste da consulta problemática:</h3>";
    
    // Teste 1: Verificar se a coleção tem coluna 'id'
    echo "<h4>Teste 1: SELECT id FROM colecoes LIMIT 1</h4>";
    try {
        $stmt = $pdo->query("SELECT id FROM colecoes LIMIT 1");
        echo "<p style='color: green;'>✅ Consulta executada com sucesso</p>";
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "<pre>" . print_r($result, true) . "</pre>";
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ Erro: " . $e->getMessage() . "</p>";
    }
    
    // Teste 2: Verificar se itens_colecao tem coluna 'id'
    echo "<h4>Teste 2: SELECT id FROM itens_colecao LIMIT 1</h4>";
    try {
        $stmt = $pdo->query("SELECT id FROM itens_colecao LIMIT 1");
        echo "<p style='color: green;'>✅ Consulta executada com sucesso</p>";
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "<pre>" . print_r($result, true) . "</pre>";
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ Erro: " . $e->getMessage() . "</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Erro geral: " . $e->getMessage() . "</p>";
}
?>
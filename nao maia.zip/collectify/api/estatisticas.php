<?php
// api/estatisticas.php - DESABILITAR ERROS
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);

// Iniciar sessão se não estiver ativa
if (session_status() === PHP_SESSION_NONE) {
    @session_start();
}

// Verificar se está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit();
}

// Incluir conexão
require_once '../includes/conexao.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $conn = getConnection();
    if (!$conn) {
        throw new Exception('Erro de conexão com o banco');
    }
    
    $usuario_id = $_SESSION['usuario_id'];
    
    // Total de itens
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM itens WHERE usuario_id = ?");
    $stmt->execute([$usuario_id]);
    $totalItens = (int)$stmt->fetchColumn();
    
    // Total na lista de desejos
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM lista_desejos WHERE usuario_id = ?");
    $stmt->execute([$usuario_id]);
    $totalDesejos = (int)$stmt->fetchColumn();
    
    // Total de coleções
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM colecoes WHERE usuario_id = ?");
    $stmt->execute([$usuario_id]);
    $totalColecoes = (int)$stmt->fetchColumn();
    
    echo json_encode([
        'success' => true,
        'totalItens' => $totalItens,
        'totalDesejos' => $totalDesejos,
        'totalColecoes' => $totalColecoes
    ]);
    
} catch (Exception $e) {
    error_log("Erro em estatisticas.php: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao carregar estatísticas'
    ]);
}
?>
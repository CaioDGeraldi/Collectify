<?php
// api/remover_desejo.php - Remover item da lista de desejos

// Desabilitar erros
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);

require_once '../includes/conexao.php';
require_once '../includes/protecao.php';

// Verificar login
verificarLogin();

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit();
}

$conn = getConnection();
if (!$conn) {
    echo json_encode(['success' => false, 'message' => 'Erro de conexão com o banco']);
    exit();
}

try {
    $usuarioId = $_SESSION['usuario_id'];
    $itemId = $_POST['item_id'] ?? null;
    
    if (!$itemId || !is_numeric($itemId)) {
        echo json_encode(['success' => false, 'message' => 'ID do item inválido']);
        exit();
    }
    
    // Verificar se o item está na lista de desejos do usuário
    $stmt = $conn->prepare("SELECT * FROM lista_desejos WHERE usuario_id = ? AND item_id = ?");
    $stmt->execute([$usuarioId, $itemId]);
    
    if ($stmt->rowCount() === 0) {
        echo json_encode(['success' => false, 'message' => 'Item não encontrado na lista de desejos']);
        exit();
    }
    
    // Remover da lista de desejos
    $stmt = $conn->prepare("DELETE FROM lista_desejos WHERE usuario_id = ? AND item_id = ?");
    
    if ($stmt->execute([$usuarioId, $itemId])) {
        echo json_encode(['success' => true, 'message' => 'Item removido da lista de desejos']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Erro ao remover item']);
    }
    
} catch(PDOException $exception) {
    error_log("Erro ao remover desejo: " . $exception->getMessage());
    echo json_encode(['success' => false, 'message' => 'Erro no servidor']);
}
?>
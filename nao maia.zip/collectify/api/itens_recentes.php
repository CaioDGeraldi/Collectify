<?php
// api/itens_recentes.php - DESABILITAR ERROS
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);

// Iniciar sessão se não estiver ativa
if (session_status() === PHP_SESSION_NONE) {
    @session_start();
}

// Verificar se está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit();
}

// Incluir conexão
require_once '../includes/conexao.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $conn = getConnection();
    if (!$conn) {
        throw new Exception('Erro de conexão com o banco');
    }
    
    $usuario_id = $_SESSION['usuario_id'];
    
    // Buscar itens recentes
    $query = "SELECT * FROM itens 
              WHERE usuario_id = :usuario_id 
              ORDER BY data_cadastro DESC 
              LIMIT 6";
    
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':usuario_id', $usuario_id, PDO::PARAM_INT);
    $stmt->execute();
    
    $itens = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'itens' => $itens,
        'total' => count($itens)
    ]);
    
} catch (Exception $e) {
    error_log("Erro em itens_recentes.php: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao carregar itens recentes'
    ]);
}
?>
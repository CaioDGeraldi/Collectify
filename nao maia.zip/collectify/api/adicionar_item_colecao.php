<?php
// api/adicionar_item_colecao.php - VERSÃO CORRIGIDA
error_reporting(0);
ini_set('display_errors', 0);

require_once '../includes/conexao.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json; charset=utf-8');

// Verificar login
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit();
}

$userId = $_SESSION['usuario_id'];

// Obter dados
$input = file_get_contents('php://input');
parse_str($input, $data);

// Verificar parâmetros
if (!isset($data['item_id']) || !isset($data['colecao_id'])) {
    echo json_encode(['success' => false, 'message' => 'Parâmetros faltando']);
    exit();
}

$itemId = intval($data['item_id']);
$colecaoId = intval($data['colecao_id']);

// Obter conexão
$pdo = getConnection();
if (!$pdo) {
    echo json_encode(['success' => false, 'message' => 'Erro de conexão']);
    exit();
}

try {
    // 1. Verificar se o item pertence ao usuário
    $stmt = $pdo->prepare("SELECT id FROM itens WHERE id = ? AND usuario_id = ?");
    $stmt->execute([$itemId, $userId]);
    
    if ($stmt->rowCount() === 0) {
        echo json_encode(['success' => false, 'message' => 'Item não encontrado']);
        exit();
    }
    
    // 2. Verificar se a coleção pertence ao usuário
    $stmt = $pdo->prepare("SELECT id FROM colecoes WHERE id = ? AND usuario_id = ?");
    $stmt->execute([$colecaoId, $userId]);
    
    if ($stmt->rowCount() === 0) {
        echo json_encode(['success' => false, 'message' => 'Coleção não encontrada']);
        exit();
    }
    
    // 3. Verificar se item já está na coleção (CORRIGIDO - não usar 'id')
    $stmt = $pdo->prepare("SELECT item_id FROM itens_colecao WHERE item_id = ? AND colecao_id = ?");
    $stmt->execute([$itemId, $colecaoId]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => false, 'message' => 'Este item já está na coleção']);
        exit();
    }
    
    // 4. Adicionar item à coleção
    $stmt = $pdo->prepare("INSERT INTO itens_colecao (item_id, colecao_id) VALUES (?, ?)");
    
    if ($stmt->execute([$itemId, $colecaoId])) {
        echo json_encode([
            'success' => true,
            'message' => '✅ Item adicionado à coleção!'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Erro ao adicionar']);
    }
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'Erro: ' . $e->getMessage()
    ]);
}
?>
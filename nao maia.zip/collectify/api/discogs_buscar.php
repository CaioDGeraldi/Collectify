<?php
// api/discogs_buscar.php - Busca na API do Discogs

header('Content-Type: application/json; charset=utf-8');

// Configurações - SEU TOKEN JÁ INSERIDO
$discogs_token = 'EyyEUoxAbZVThrFhNTvaviVfXwdYlgDTZUhvlYSV';
$user_agent = 'Collectify/1.0 +http://localhost/collectify';

// Verificar parâmetro de busca
if (!isset($_GET['q']) || empty(trim($_GET['q']))) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Parâmetro de busca (q) é obrigatório'
    ]);
    exit();
}

$query = urlencode(trim($_GET['q']));
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$per_page = isset($_GET['per_page']) ? intval($_GET['per_page']) : 8;

// URL da API Discogs
$url = "https://api.discogs.com/database/search?q={$query}&type=release&page={$page}&per_page={$per_page}";

// Configurar requisição
$options = [
    'http' => [
        'method' => 'GET',
        'header' => [
            "Authorization: Discogs token={$discogs_token}",
            "User-Agent: {$user_agent}",
            "Accept: application/json"
        ]
    ]
];

$context = stream_context_create($options);

try {
    // Fazer requisição
    $response = file_get_contents($url, false, $context);
    
    if ($response === FALSE) {
        throw new Exception('Erro ao acessar API Discogs');
    }
    
    $data = json_decode($response, true);
    
    // Processar resultados
    $resultados = [];
    
    if (isset($data['results']) && count($data['results']) > 0) {
        foreach ($data['results'] as $item) {
            // Extrair informações principais
            $resultado = [
                'id' => $item['id'] ?? null,
                'title' => $item['title'] ?? 'Desconhecido',
                'artist' => $item['artist'] ?? 'Artista Desconhecido',
                'year' => $item['year'] ?? null,
                'label' => isset($item['label']) ? (is_array($item['label']) ? implode(', ', $item['label']) : $item['label']) : null,
                'format' => isset($item['format']) ? (is_array($item['format']) ? implode(', ', $item['format']) : $item['format']) : null,
                'genre' => isset($item['genre']) ? (is_array($item['genre']) ? implode(', ', $item['genre']) : $item['genre']) : null,
                'style' => isset($item['style']) ? (is_array($item['style']) ? implode(', ', $item['style']) : $item['style']) : null,
                'thumb' => $item['thumb'] ?? null,
                'cover_image' => $item['cover_image'] ?? null,
                'resource_url' => $item['resource_url'] ?? null
            ];
            
            // Extrair artista do título se necessário
            if ($resultado['artist'] === 'Artista Desconhecido' && strpos($resultado['title'], ' - ') !== false) {
                $parts = explode(' - ', $resultado['title'], 2);
                $resultado['artist'] = trim($parts[0]);
                $resultado['title'] = trim($parts[1]);
            }
            
            $resultados[] = $resultado;
        }
    }
    
    echo json_encode([
        'success' => true,
        'query' => urldecode($query),
        'pagination' => $data['pagination'] ?? null,
        'resultados' => $resultados,
        'total' => count($resultados)
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Erro na busca: ' . $e->getMessage()
    ]);
}
?>
<?php
// api/criar_colecao.php - VERSÃO SIMPLIFICADA E FUNCIONAL

// Desligar exibição de erros na tela
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL & ~E_DEPRECATED & ~E_STRICT);

// Iniciar sessão
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// SEMPRE retornar JSON
header('Content-Type: application/json; charset=utf-8');

// Só aceitar POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); // Method Not Allowed
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit();
}

// Verificar login
if (!isset($_SESSION['usuario_id'])) {
    http_response_code(401); // Unauthorized
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit();
}

// Incluir conexão
require_once '../includes/conexao.php';

try {
    // Pegar dados do POST
    $nome = isset($_POST['nome']) ? trim($_POST['nome']) : '';
    $categoria = isset($_POST['categoria']) ? $_POST['categoria'] : 'personalizada';
    $descricao = isset($_POST['descricao']) ? trim($_POST['descricao']) : '';
    
    // Validar
    if (empty($nome)) {
        echo json_encode(['success' => false, 'message' => 'Nome da coleção é obrigatório']);
        exit();
    }
    
    // Validar categoria
    if (!in_array($categoria, ['genero', 'favoritas', 'tipo_item', 'personalizada'])) {
        $categoria = 'personalizada';
    }
    
    // Conectar ao banco
    $conn = getConnection();
    if (!$conn) {
        throw new Exception('Erro de conexão com banco');
    }
    
    $usuario_id = $_SESSION['usuario_id'];
    
    // Verificar se já existe
    $stmt = $conn->prepare("SELECT id FROM colecoes WHERE nome = ? AND usuario_id = ?");
    $stmt->execute([$nome, $usuario_id]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => false, 'message' => 'Já existe uma coleção com este nome']);
        exit();
    }
    
    // Inserir nova coleção
    $stmt = $conn->prepare("INSERT INTO colecoes (nome, categoria, descricao, usuario_id) VALUES (?, ?, ?, ?)");
    
    if ($stmt->execute([$nome, $categoria, $descricao, $usuario_id])) {
        $novo_id = $conn->lastInsertId();
        
        echo json_encode([
            'success' => true,
            'message' => 'Coleção criada com sucesso!',
            'colecao_id' => $novo_id
        ]);
    } else {
        throw new Exception('Erro ao salvar no banco');
    }
    
} catch (Exception $e) {
    http_response_code(500); // Internal Server Error
    echo json_encode(['success' => false, 'message' => 'Erro no servidor: ' . $e->getMessage()]);
}
?>
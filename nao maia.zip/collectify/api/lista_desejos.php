<?php
// api/lista_desejos.php - DESABILITAR ERROS
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);

// Não iniciar sessão aqui - já foi iniciada em protecao.php
// REMOVA: session_start();

require_once '../includes/conexao.php';
require_once '../includes/protecao.php';

// Verificar login
verificarLogin();

header('Content-Type: application/json; charset=utf-8');

$conn = getConnection();
if (!$conn) {
    echo json_encode(['success' => false, 'message' => 'Erro de conexão com o banco']);
    exit();
}

try {
    $usuarioId = $_SESSION['usuario_id'];
    
    $query = "SELECT i.*, ld.data_adicao 
              FROM itens i
              INNER JOIN lista_desejos ld ON i.id = ld.item_id
              WHERE ld.usuario_id = :usuario_id
              ORDER BY ld.data_adicao DESC";
    
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':usuario_id', $usuarioId);
    $stmt->execute();
    
    $itens = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'itens' => $itens,
        'total' => count($itens)
    ]);
    
} catch(PDOException $exception) {
    error_log("Erro ao carregar lista de desejos: " . $exception->getMessage());
    echo json_encode(['success' => false, 'message' => 'Erro no servidor']);
}
?>
<?php
// detalhes_colecao.php - Detalhes de uma coleção específica
// Este arquivo está na pasta api/

// Iniciar sessão se não estiver ativa
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Verificar se está logado
if (!isset($_SESSION['usuario_id'])) {
    $_SESSION['erro'] = 'Por favor, faça login para acessar esta página.';
    header('Location: ../login.html');
    exit();
}

// Verificar se o ID da coleção foi passado
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['erro'] = 'Coleção não especificada.';
    header('Location: ../minhas_colecoes.php');
    exit();
}

$colecao_id = intval($_GET['id']);
require_once '../includes/conexao.php';

try {
    $conn = getConnection();
    if (!$conn) {
        throw new Exception('Erro de conexão com o banco');
    }
    
    // Buscar informações da coleção
    $query = "
        SELECT c.*, 
               COUNT(ic.item_id) as total_itens
        FROM colecoes c
        LEFT JOIN itens_colecao ic ON c.id = ic.colecao_id
        WHERE c.id = :id AND c.usuario_id = :usuario_id
        GROUP BY c.id
    ";
    
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':id', $colecao_id, PDO::PARAM_INT);
    $stmt->bindParam(':usuario_id', $_SESSION['usuario_id'], PDO::PARAM_INT);
    $stmt->execute();
    
    if ($stmt->rowCount() === 0) {
        $_SESSION['erro'] = 'Coleção não encontrada ou você não tem permissão para acessá-la.';
        header('Location: ../minhas_colecoes.php');
        exit();
    }
    
    $colecao = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Buscar itens da coleção
    $queryItens = "
        SELECT i.* 
        FROM itens i
        INNER JOIN itens_colecao ic ON i.id = ic.item_id
        WHERE ic.colecao_id = :colecao_id
        ORDER BY i.nome ASC
    ";
    
    $stmtItens = $conn->prepare($queryItens);
    $stmtItens->bindParam(':colecao_id', $colecao_id, PDO::PARAM_INT);
    $stmtItens->execute();
    $itens = $stmtItens->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    error_log("Erro em detalhes_colecao.php: " . $e->getMessage());
    $_SESSION['erro'] = 'Erro ao carregar detalhes da coleção.';
    header('Location: ../minhas_colecoes.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($colecao['nome']); ?> - Collectify</title>
    <link rel="stylesheet" href="../assets/css/estilos.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- CSS do modal -->
    <style>
    .modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1000;
    }

    .modal-content {
        background: white;
        border-radius: 8px;
        max-width: 800px;
        width: 90%;
        max-height: 80vh;
        overflow-y: auto;
    }

    .modal-header {
        padding: 1rem;
        border-bottom: 1px solid #eee;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .modal-body {
        padding: 1rem;
    }

    .modal-footer {
        padding: 1rem;
        border-top: 1px solid #eee;
        text-align: right;
    }

    .modal-close {
        background: none;
        border: none;
        font-size: 1.5rem;
        cursor: pointer;
        color: #666;
    }

    .itens-lista {
        display: grid;
        gap: 1rem;
    }

    .item-lista {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 1rem;
        border: 1px solid #eee;
        border-radius: 6px;
        transition: background-color 0.2s;
    }

    .item-lista:hover {
        background-color: #f9f9f9;
    }

    .item-info {
        flex: 1;
    }

    .item-info h4 {
        margin: 0 0 0.25rem 0;
        color: #333;
    }

    .item-meta {
        margin: 0;
        color: #666;
        font-size: 0.9rem;
    }

    .loading-modal {
        text-align: center;
        padding: 2rem;
        color: #666;
    }

    <style>
/* Estilos para a tabela com imagens */
.table td {
    vertical-align: middle;
}

.table img {
    border: 2px solid #ddd;
    transition: transform 0.2s;
}

.table img:hover {
    transform: scale(1.1);
    border-color: #4a6fa5;
}

.thumbnail-cell {
    width: 60px;
}

/* Badges para tipos de mídia */
.item-badge {
    display: inline-block;
    padding: 0.25rem 0.5rem;
    border-radius: 4px;
    font-size: 0.85rem;
    font-weight: 500;
}

.item-badge.cd {
    background-color: #e3f2fd;
    color: #1565c0;
}

.item-badge.lp {
    background-color: #f3e5f5;
    color: #7b1fa2;
}

.item-badge.boxset {
    background-color: #e8f5e9;
    color: #2e7d32;
}

.item-badge.livro {
    background-color: #fff3e0;
    color: #ef6c00;
}

/* Badges para tipos de mídia */
.item-badge {
    display: inline-block;
    padding: 0.25rem 0.5rem;
    border-radius: 4px;
    font-size: 0.85rem;
    font-weight: 500;
}

.item-badge.cd {
    background-color: #e3f2fd;
    color: #1565c0;
}

.item-badge.lp {
    background-color: #f3e5f5;
    color: #7b1fa2;
}

.item-badge.boxset {
    background-color: #e8f5e9;
    color: #2e7d32;
}

.item-badge.livro {
    background-color: #fff3e0;
    color: #ef6c00;
}

.item-badge.default {
    background-color: #f5f5f5;
    color: #666;
}

/* Modal de adicionar item */
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1000;
}

.modal-content {
    background: white;
    border-radius: 8px;
    max-width: 800px;
    width: 90%;
    max-height: 80vh;
    overflow-y: auto;
}

.modal-header {
    padding: 1rem;
    border-bottom: 1px solid #eee;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-body {
    padding: 1rem;
}

.modal-footer {
    padding: 1rem;
    border-top: 1px solid #eee;
    text-align: right;
}

.modal-close {
    background: none;
    border: none;
    font-size: 1.5rem;
    cursor: pointer;
    color: #666;
}

/* Loading no modal */
.loading-modal {
    text-align: center;
    padding: 2rem;
    color: #666;
}

.loading-modal i {
    font-size: 2rem;
    margin-bottom: 1rem;
}

</style>
    </style>
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="logo">
                <i class="fas fa-compact-disc"></i>
                <h1>Collectify</h1>
            </div>
            <ul class="nav-links">
                <li><a href="../dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="../minhas_colecoes.php" class="active"><i class="fas fa-folder"></i> Minhas Coleções</a></li>
                <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
            </ul>
        </nav>
    </header>

    <div class="dashboard-container">
        <aside class="sidebar">
            <ul>
                <li><a href="../dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="../cadastrar_item.php"><i class="fas fa-plus-circle"></i> Novo Item</a></li>
                <li><a href="../pesquisar_item.php"><i class="fas fa-search"></i> Pesquisar</a></li>
                <li><a href="../minhas_colecoes.php" class="active"><i class="fas fa-folder"></i> Minhas Coleções</a></li>
                <li><a href="../lista_desejos.php"><i class="fas fa-heart"></i> Lista de Desejos</a></li>
            </ul>
        </aside>

        <main class="main-content">
            <div class="page-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                <div>
                    <h2 style="margin-bottom: 0.5rem;">
                        <i class="fas fa-folder"></i> <?php echo htmlspecialchars($colecao['nome']); ?>
                    </h2>
                    <p style="color: #666; margin-bottom: 0;">
                        Categoria: <?php echo htmlspecialchars($colecao['categoria']); ?> • 
                        Itens: <?php echo $colecao['total_itens']; ?>
                    </p>
                </div>
                <div>
                    <a href="../minhas_colecoes.php" class="btn-secondary">
                        <i class="fas fa-arrow-left"></i> Voltar
                    </a>
                </div>
            </div>
            
            <?php if (!empty($colecao['descricao'])): ?>
            <div class="form-container" style="margin-bottom: 2rem;">
                <h3><i class="fas fa-info-circle"></i> Descrição</h3>
                <p><?php echo nl2br(htmlspecialchars($colecao['descricao'])); ?></p>
            </div>
            <?php endif; ?>
            
            <div class="form-container">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                    <h3><i class="fas fa-compact-disc"></i> Itens na Coleção (<?php echo count($itens); ?>)</h3>
                    <button class="btn-primary" onclick="adicionarItem()">
                        <i class="fas fa-plus"></i> Adicionar Item
                    </button>
                </div>
                
                <?php if (!empty($itens)): ?>
                <div class="table-container">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Artista/Banda</th>
                                <th>Nome</th>
                                <th>Ano</th>
                                <th>Tipo</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                           <?php foreach ($itens as $item): ?>
<tr>
    <td>
        <div style="display: flex; align-items: center; gap: 10px;">
            <?php if ($item['imagem']): ?>
                <img src="../assets/uploads/<?php echo htmlspecialchars($item['imagem']); ?>" 
                     alt="<?php echo htmlspecialchars($item['nome']); ?>"
                     style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;">
            <?php else: ?>
                <div style="width: 50px; height: 50px; background: #666; border-radius: 4px; 
                            display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-compact-disc" style="color: white; font-size: 1.5rem;"></i>
                </div>
            <?php endif; ?>
            <span><?php echo htmlspecialchars($item['artista_banda']); ?></span>
        </div>
    </td>
    <td><?php echo htmlspecialchars($item['nome']); ?></td>
    <td><?php echo htmlspecialchars($item['ano_lancamento']); ?></td>
    <td>
        <span class="item-badge <?php echo strtolower($item['tipo_midia']); ?>">
            <?php echo htmlspecialchars($item['tipo_midia']); ?>
        </span>
    </td>
    <td>
        <a href="../detalhes_item.php?id=<?php echo $item['id']; ?>" class="btn-primary btn-sm">
            <i class="fas fa-eye"></i>
        </a>
        <button class="btn-secondary btn-sm" onclick="removerDaColecao(<?php echo $item['id']; ?>, <?php echo $colecao_id; ?>)">
            <i class="fas fa-times"></i>
        </button>
    </td>
</tr>
<?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="empty-state" style="text-align: center; padding: 3rem;">
                    <i class="fas fa-inbox" style="font-size: 3rem; color: #ccc; margin-bottom: 1rem;"></i>
                    <h3>Esta coleção está vazia</h3>
                    <p>Adicione itens para começar a organizar sua coleção.</p>
                    <button class="btn-primary" onclick="adicionarItem()" style="margin-top: 1rem;">
                        <i class="fas fa-plus"></i> Adicionar Primeiro Item
                    </button>
                </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- Modal para adicionar itens à coleção -->
    <div id="modal-adicionar-item" class="modal-overlay" style="display: none;">
        <div class="modal-content" style="max-width: 800px;">
            <div class="modal-header">
                <h3><i class="fas fa-plus"></i> Adicionar Item à Coleção</h3>
                <button class="modal-close" onclick="fecharModalAdicionar()">&times;</button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label for="busca-item"><i class="fas fa-search"></i> Buscar itens:</label>
                    <div style="display: flex; gap: 10px;">
                        <input type="text" id="busca-item" class="form-control" 
                               placeholder="Digite nome do álbum ou artista..." 
                               onkeyup="buscarItensDisponiveis()">
                        <button class="btn-primary" onclick="buscarItensDisponiveis()">
                            <i class="fas fa-search"></i> Buscar
                        </button>
                    </div>
                </div>
                
                <div id="resultados-busca" style="margin-top: 1rem; max-height: 400px; overflow-y: auto;"></div>
            </div>
            <div class="modal-footer">
                <button class="btn-secondary" onclick="fecharModalAdicionar()">Cancelar</button>
            </div>
        </div>
    </div>

<script>
    // Variável global
    const colecaoId = <?php echo $colecao_id; ?>;
    
    // Função para remover item da coleção
    function removerDaColecao(itemId, colecaoId) {
        if (confirm('Remover este item da coleção?')) {
            fetch('remover_item_colecao.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `item_id=${itemId}&colecao_id=${colecaoId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    location.reload();
                } else {
                    alert('Erro: ' + data.message);
                }
            })
            .catch(error => {
                alert('Erro de conexão');
            });
        }
    }
    
    // ========== FUNÇÕES DO MODAL ==========
    
    // Função para abrir o modal de adicionar item
    function adicionarItem() {
        document.getElementById('modal-adicionar-item').style.display = 'flex';
        document.getElementById('busca-item').value = '';
        document.getElementById('resultados-busca').innerHTML = '';
        buscarItensDisponiveis();
    }
    
    // Função para fechar o modal
    function fecharModalAdicionar() {
        document.getElementById('modal-adicionar-item').style.display = 'none';
    }
    
    // Função para buscar itens disponíveis
    function buscarItensDisponiveis() {
        const termo = document.getElementById('busca-item').value;
        const resultadosDiv = document.getElementById('resultados-busca');
        
        resultadosDiv.innerHTML = '<div class="loading-modal"><i class="fas fa-spinner fa-spin"></i> Buscando itens...</div>';
        
        // URL com parâmetros
        const url = `buscar_itens_colecao.php?colecao_id=${colecaoId}&q=${encodeURIComponent(termo)}`;
        console.log('🔍 URL da busca:', url);
        
        fetch(url)
            .then(response => {
                console.log('📥 Status:', response.status);
                return response.json();
            })
            .then(data => {
                console.log('✅ Dados recebidos:', data);
                
                if (data.success && data.itens && data.itens.length > 0) {
                    let html = '<div class="itens-lista">';
                    
                    data.itens.forEach(item => {
                        // HTML da imagem
                        let imagemHtml = '';
                        if (item.imagem) {
                            imagemHtml = `<img src="../assets/uploads/${item.imagem}" alt="${item.nome}" 
                                         style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px; margin-right: 10px;">`;
                        } else {
                            imagemHtml = `<div style="width: 50px; height: 50px; background: #666; border-radius: 4px; 
                                         display: flex; align-items: center; justify-content: center; margin-right: 10px;">
                                         <i class="fas fa-compact-disc" style="color: white; font-size: 1.5rem;"></i>
                                       </div>`;
                        }
                        
                        // Determinar classe do badge
                        let badgeClass = 'default';
                        if (item.tipo_midia) {
                            badgeClass = item.tipo_midia.toLowerCase();
                        }
                        
                        html += `
                        <div class="item-lista">
                            <div class="item-info" style="display: flex; align-items: center;">
                                ${imagemHtml}
                                <div>
                                    <h4>${item.nome || 'Sem nome'}</h4>
                                    <p class="item-meta">${item.artista_banda || 'Artista desconhecido'} • ${item.ano_lancamento || 'N/A'}</p>
                                    <p class="item-meta">
                                        <span class="item-badge ${badgeClass}">
                                            ${item.tipo_midia || 'Desconhecido'}
                                        </span>
                                    </p>
                                </div>
                            </div>
                            <div>
                                <button class="btn-primary btn-sm" onclick="adicionarItemAColecao(${item.id})">
                                    <i class="fas fa-plus"></i> Adicionar
                                </button>
                            </div>
                        </div>`;
                    });
                    
                    html += '</div>';
                    resultadosDiv.innerHTML = html;
                } else {
                    resultadosDiv.innerHTML = `
                        <div style="text-align: center; padding: 2rem; color: #666;">
                            <i class="fas fa-inbox" style="font-size: 2rem; margin-bottom: 1rem;"></i>
                            <p>${termo ? `Nenhum item encontrado para "${termo}"` : 'Você não tem itens disponíveis para adicionar.'}</p>
                            ${!termo ? '<p><a href="../cadastrar_item.php" class="btn-primary btn-sm">Cadastrar novo item</a></p>' : ''}
                        </div>
                    `;
                }
            })
            .catch(error => {
                console.error('❌ Erro na busca:', error);
                resultadosDiv.innerHTML = `
                    <div style="text-align: center; padding: 2rem; color: #e74c3c;">
                        <i class="fas fa-exclamation-triangle" style="font-size: 2rem; margin-bottom: 1rem;"></i>
                        <p>Erro ao buscar itens.</p>
                        <button class="btn-secondary btn-sm" onclick="buscarItensDisponiveis()" style="margin-top: 1rem;">
                            <i class="fas fa-redo"></i> Tentar Novamente
                        </button>
                    </div>
                `;
            });
    }
    
    // Função para adicionar item à coleção
    function adicionarItemAColecao(itemId) {
        console.log('➕ Adicionando item', itemId, 'à coleção', colecaoId);
        
        if (confirm('Adicionar este item à coleção?')) {
            // Mostrar loading no botão
            const button = event.target;
            const originalHTML = button.innerHTML;
            button.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
            button.disabled = true;
            
            fetch('adicionar_item_colecao.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `item_id=${itemId}&colecao_id=${colecaoId}`
            })
            .then(response => {
                console.log('📥 Status adição:', response.status);
                return response.json();
            })
            .then(data => {
                console.log('✅ Resposta adição:', data);
                
                // Restaurar botão
                button.innerHTML = originalHTML;
                button.disabled = false;
                
                if (data.success) {
                    alert(data.message);
                    // Recarregar a página após 1 segundo
                    setTimeout(() => {
                        location.reload();
                    }, 1000);
                } else {
                    alert('❌ ' + data.message);
                }
            })
            .catch(error => {
                // Restaurar botão
                button.innerHTML = originalHTML;
                button.disabled = false;
                console.error('❌ Erro na adição:', error);
                alert('❌ Erro de conexão');
            });
        }
    }
    
    // Fechar modal ao clicar fora
    document.getElementById('modal-adicionar-item').addEventListener('click', function(e) {
        if (e.target === this) {
            fecharModalAdicionar();
        }
    });
    
    // Buscar ao pressionar Enter
    document.getElementById('busca-item').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            buscarItensDisponiveis();
        }
    });
    
    console.log('✅ Página de detalhes da coleção carregada');
    console.log('📁 Coleção ID:', colecaoId);
</script>

</body>
</html>
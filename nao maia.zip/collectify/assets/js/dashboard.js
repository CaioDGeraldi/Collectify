document.addEventListener('DOMContentLoaded', function() {
    console.log('Dashboard carregado');
    carregarEstatisticas();
    carregarItensRecentes();
});

function carregarEstatisticas() {
    console.log('Carregando estatísticas...');
    
    fetch('api/estatisticas.php')
        .then(response => {
            console.log('Status estatísticas:', response.status, response.ok);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log('Estatísticas recebidas:', data);
            if (data.success) {
                document.getElementById('total-itens').textContent = data.totalItens || 0;
                document.getElementById('total-desejos').textContent = data.totalDesejos || 0;
                document.getElementById('total-colecoes').textContent = data.totalColecoes || 0;
            } else {
                console.error('Erro nas estatísticas:', data.message);
            }
        })
        .catch(error => {
            console.error('Erro ao carregar estatísticas:', error);
            document.getElementById('total-itens').textContent = 'Erro';
            document.getElementById('total-desejos').textContent = 'Erro';
            document.getElementById('total-colecoes').textContent = 'Erro';
        });
}

function carregarItensRecentes() {
    console.log('Carregando itens recentes...');
    
    fetch('api/itens_recentes.php')
        .then(response => {
            console.log('Status itens:', response.status, response.ok);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log('Dados recebidos:', data);
            const container = document.getElementById('itens-recentes');
            
            if (data.success && data.itens && data.itens.length > 0) {
                console.log(`${data.itens.length} itens encontrados`);
                
                container.innerHTML = data.itens.map(item => {
                    console.log('Processando item:', item);
                    
                    // CORREÇÃO DO CAMINHO DA IMAGEM
                    const imagemHtml = item.imagem 
                        ? `<img src="assets/uploads/${item.imagem}" alt="${item.nome}" style="width: 100%; height: 100%; object-fit: cover;">`
                        : `<i class="fas fa-compact-disc" style="font-size: 4rem; color: white;"></i>`;
                    
                    return `
                    <div class="item-card">
                        <div class="item-image" style="background-color: #666; height: 150px; display: flex; align-items: center; justify-content: center; overflow: hidden;">
                            ${imagemHtml}
                        </div>
                        <div class="item-info">
                            <h3>${escapeHtml(item.nome || 'Sem nome')}</h3>
                            <p class="item-meta">${escapeHtml(item.artista_banda || 'Artista desconhecido')}</p>
                            <p class="item-meta">${item.ano_lancamento || 'N/A'} • ${item.tipo_midia || 'Desconhecido'}</p>
                            <div class="item-actions">
                                <a href="detalhes_item.php?id=${item.id}" class="btn-primary btn-sm">
                                    <i class="fas fa-eye"></i> Ver
                                </a>
                                <button class="btn-secondary btn-sm" onclick="adicionarDesejo(${item.id})">
                                    <i class="fas fa-heart"></i> Desejo
                                </button>
                            </div>
                        </div>
                    </div>`;
                }).join('');
                
            } else {
                console.log('Nenhum item ou erro:', data.message);
                container.innerHTML = '<p style="grid-column: 1 / -1; text-align: center; padding: 2rem; color: #666;">Nenhum item cadastrado ainda.</p>';
            }
        })
        .catch(error => {
            console.error('Erro ao carregar itens recentes:', error);
            const container = document.getElementById('itens-recentes');
            container.innerHTML = `
                <div style="grid-column: 1 / -1; text-align: center; padding: 2rem;">
                    <i class="fas fa-exclamation-triangle" style="font-size: 2rem; color: #e74c3c; margin-bottom: 1rem;"></i>
                    <p style="color: #e74c3c;">Erro ao carregar itens recentes.</p>
                    <p style="color: #666; font-size: 0.9rem;">Verifique o console (F12) para detalhes.</p>
                </div>`;
        });
}

function verDetalhes(itemId) {
    window.location.href = `detalhes_item.php?id=${itemId}`;
}

function adicionarDesejo(itemId) {
    if (confirm('Adicionar este item à lista de desejos?')) {
        fetch('api/adicionar_desejos.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `item_id=${itemId}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert(data.message);
                carregarEstatisticas();
            } else {
                alert('Erro: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Erro:', error);
            alert('Erro ao adicionar à lista de desejos');
        });
    }
}

// Função utilitária para segurança
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Atualizar estatísticas a cada 30 segundos
setInterval(() => {
    carregarEstatisticas();
}, 30000);
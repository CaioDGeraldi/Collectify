// Validação de formulários
document.addEventListener('DOMContentLoaded', function() {
    const forms = document.querySelectorAll('form[needs-validation]');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            if (!validateForm(this)) {
                event.preventDefault();
                event.stopPropagation();
            }
        });
    });
});

function validateForm(form) {
    let isValid = true;
    
    // Validar campos obrigatórios
    const requiredFields = form.querySelectorAll('[required]');
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            markAsInvalid(field, 'Este campo é obrigatório');
            isValid = false;
        } else {
            markAsValid(field);
        }
    });
    
    // Validação específica por tipo
    const emailFields = form.querySelectorAll('input[type="email"]');
    emailFields.forEach(field => {
        if (field.value && !isValidEmail(field.value)) {
            markAsInvalid(field, 'E-mail inválido');
            isValid = false;
        }
    });
    
    const numberFields = form.querySelectorAll('input[type="number"]');
    numberFields.forEach(field => {
        if (field.hasAttribute('min') && field.value < field.getAttribute('min')) {
            markAsInvalid(field, `Valor mínimo: ${field.getAttribute('min')}`);
            isValid = false;
        }
        if (field.hasAttribute('max') && field.value > field.getAttribute('max')) {
            markAsInvalid(field, `Valor máximo: ${field.getAttribute('max')}`);
            isValid = false;
        }
    });
    
    // Validação de arquivos
    const fileFields = form.querySelectorAll('input[type="file"]');
    fileFields.forEach(field => {
        if (field.hasAttribute('accept') && field.files.length > 0) {
            const file = field.files[0];
            const acceptedTypes = field.getAttribute('accept').split(',');
            const fileType = file.type;
            
            if (!acceptedTypes.some(type => {
                if (type.includes('/*')) {
                    return fileType.startsWith(type.replace('/*', ''));
                }
                return fileType === type;
            })) {
                markAsInvalid(field, 'Tipo de arquivo não permitido');
                isValid = false;
            }
            
            // Verificar tamanho máximo (5MB)
            const maxSize = 5 * 1024 * 1024; // 5MB
            if (file.size > maxSize) {
                markAsInvalid(field, 'Arquivo muito grande (máx. 5MB)');
                isValid = false;
            }
        }
    });
    
    return isValid;
}

function markAsInvalid(element, message) {
    element.style.borderColor = '#721c24';
    element.style.backgroundColor = '#f8d7da';
    
    // Remover mensagem anterior
    const existingMessage = element.nextElementSibling;
    if (existingMessage && existingMessage.classList.contains('error-message')) {
        existingMessage.remove();
    }
    
    // Adicionar nova mensagem
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.textContent = message;
    errorDiv.style.cssText = `
        color: #721c24;
        font-size: 0.875rem;
        margin-top: 0.25rem;
    `;
    
    element.parentNode.insertBefore(errorDiv, element.nextSibling);
    
    // Focar no primeiro campo inválido
    if (!element.hasAttribute('data-focused')) {
        element.focus();
        element.setAttribute('data-focused', 'true');
    }
}

function markAsValid(element) {
    element.style.borderColor = '';
    element.style.backgroundColor = '';
    
    // Remover mensagem de erro
    const errorMessage = element.nextElementSibling;
    if (errorMessage && errorMessage.classList.contains('error-message')) {
        errorMessage.remove();
    }
    
    element.removeAttribute('data-focused');
}

function isValidEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

// Validação em tempo real
document.addEventListener('input', function(event) {
    const target = event.target;
    if (target.hasAttribute('required') && target.value.trim()) {
        markAsValid(target);
    }
});
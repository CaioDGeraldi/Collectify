// assets/js/discogs_integracao.js
class DiscogsIntegration {
    constructor() {
        this.searchResults = [];
        this.currentPage = 1;
        this.totalPages = 1;
        this.currentQuery = '';
    }
    
    // Executar busca na Discogs
    async search(query) {
        if (!query || query.trim().length < 2) {
            this.showMessage('Digite pelo menos 2 caracteres para buscar', 'alerta');
            return;
        }
        
        this.currentQuery = query;
        this.currentPage = 1;
        
        const resultsDiv = document.getElementById('api-resultados');
        resultsDiv.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i> Buscando na Discogs...</div>';
        
        try {
            const response = await fetch(`api/discogs_buscar.php?q=${encodeURIComponent(query)}&page=${this.currentPage}`);
            const data = await response.json();
            
            if (data.success && data.resultados.length > 0) {
                this.searchResults = data.resultados;
                this.totalPages = data.pagination ? data.pagination.pages : 1;
                this.displayResults(data.resultados);
                this.showMessage(`Encontrados ${data.total} resultados para "${data.query}"`, 'sucesso');
            } else {
                resultsDiv.innerHTML = `
                    <div class="empty-state">
                        <i class="fas fa-search" style="font-size: 3rem; color: #ccc;"></i>
                        <p>Nenhum resultado encontrado para "${query}"</p>
                        <p>Tente usar termos diferentes ou mais específicos.</p>
                    </div>
                `;
                this.showMessage('Nenhum resultado encontrado', 'alerta');
            }
        } catch (error) {
            console.error('Erro na busca:', error);
            resultsDiv.innerHTML = `
                <div class="error-state">
                    <i class="fas fa-exclamation-triangle" style="font-size: 3rem; color: #e74c3c;"></i>
                    <p>Erro ao buscar na Discogs</p>
                    <p>Verifique sua conexão ou tente novamente.</p>
                </div>
            `;
            this.showMessage('Erro na busca. Tente novamente.', 'erro');
        }
    }
    
    // Mostrar resultados na tela
    displayResults(results) {
        const resultsDiv = document.getElementById('api-resultados');
        
        let html = `<div class="discogs-results">`;
        
        results.forEach((item, index) => {
            // Extrair tipo de mídia do formato
            let tipoMidia = 'Desconhecido';
            if (item.format) {
                const formatLower = item.format.toLowerCase();
                if (formatLower.includes('cd')) tipoMidia = 'CD';
                else if (formatLower.includes('vinyl') || formatLower.includes('lp')) tipoMidia = 'LP';
                else if (formatLower.includes('box')) tipoMidia = 'BoxSet';
            }
            
            html += `
                <div class="discogs-item" data-index="${index}">
                    <div class="discogs-item-content">
                        ${item.thumb ? `
                            <div class="discogs-thumb">
                                <img src="${item.thumb}" alt="${item.title}" loading="lazy">
                            </div>
                        ` : `
                            <div class="discogs-thumb placeholder">
                                <i class="fas fa-compact-disc"></i>
                            </div>
                        `}
                        
                        <div class="discogs-info">
                            <h4>${this.escapeHtml(item.title)}</h4>
                            <p class="artist"><strong>Artista:</strong> ${this.escapeHtml(item.artist)}</p>
                            
                            <div class="discogs-meta">
                                ${item.year ? `<span><i class="far fa-calendar"></i> ${item.year}</span>` : ''}
                                ${item.label ? `<span><i class="fas fa-record-vinyl"></i> ${this.truncateText(item.label, 30)}</span>` : ''}
                                ${item.format ? `<span><i class="fas fa-compact-disc"></i> ${this.truncateText(item.format, 20)}</span>` : ''}
                            </div>
                            
                            <div class="discogs-actions">
                                <button class="btn-primary btn-sm" onclick="discogs.selectResult(${index})">
                                    <i class="fas fa-check"></i> Usar este
                                </button>
                                <button class="btn-secondary btn-sm" onclick="discogs.viewDetails(${item.id})">
                                    <i class="fas fa-info-circle"></i> Detalhes
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        });
        
        // Adicionar paginação se houver mais páginas
        if (this.totalPages > 1) {
            html += `
                <div class="discogs-pagination">
                    <button class="btn-secondary btn-sm" ${this.currentPage <= 1 ? 'disabled' : ''} 
                            onclick="discogs.prevPage()">
                        <i class="fas fa-chevron-left"></i> Anterior
                    </button>
                    <span>Página ${this.currentPage} de ${this.totalPages}</span>
                    <button class="btn-secondary btn-sm" ${this.currentPage >= this.totalPages ? 'disabled' : ''} 
                            onclick="discogs.nextPage()">
                        Próxima <i class="fas fa-chevron-right"></i>
                    </button>
                </div>
            `;
        }
        
        html += `</div>`;
        resultsDiv.innerHTML = html;
    }
    
    // Selecionar resultado e preencher formulário
    selectResult(index) {
        const item = this.searchResults[index];
        
        if (!item) return;
        
        // Preencher campos do formulário
        document.getElementById('artista_banda').value = item.artist;
        document.getElementById('nome').value = item.title;
        document.getElementById('ano_lancamento').value = item.year || '';
        document.getElementById('gravadora').value = item.label || '';
        
        // Tentar detectar tipo de mídia automaticamente
        if (item.format) {
            const formatLower = item.format.toLowerCase();
            const tipoSelect = document.getElementById('tipo_midia');
            
            if (formatLower.includes('cd') || formatLower.includes('compact disc')) {
                tipoSelect.value = 'CD';
            } else if (formatLower.includes('vinyl') || formatLower.includes('lp') || formatLower.includes('12"') || formatLower.includes('7"')) {
                tipoSelect.value = 'LP';
            } else if (formatLower.includes('box') || formatLower.includes('set')) {
                tipoSelect.value = 'BoxSet';
            }
        }
        
        // Se houver imagem, sugerir download
        if (item.cover_image && confirm(`Deseja usar a capa do álbum como imagem?\n\n${item.cover_image}`)) {
            // Marcar para download posterior (o download real seria no backend)
            document.getElementById('imagem_url').value = item.cover_image;
            this.showMessage('Imagem será baixada ao salvar o item', 'info');
        }
        
        // Fechar resultados e mostrar mensagem
        document.getElementById('api-pesquisa').style.display = 'none';
        this.showMessage(`Dados de "${item.title}" preenchidos! Complete os demais campos.`, 'sucesso');
    }
    
    // Ver detalhes do item
    async viewDetails(discogsId) {
        try {
            const response = await fetch(`api/discogs_detalhes.php?id=${discogsId}`);
            const data = await response.json();
            
            if (data.success) {
                this.showDetailsModal(data.detalhes);
            } else {
                this.showMessage('Erro ao carregar detalhes', 'erro');
            }
        } catch (error) {
            console.error('Erro ao carregar detalhes:', error);
            this.showMessage('Erro ao carregar detalhes', 'erro');
        }
    }
    
    // Navegação entre páginas
    async nextPage() {
        if (this.currentPage < this.totalPages) {
            this.currentPage++;
            await this.searchPage(this.currentPage);
        }
    }
    
    async prevPage() {
        if (this.currentPage > 1) {
            this.currentPage--;
            await this.searchPage(this.currentPage);
        }
    }
    
    async searchPage(page) {
        const resultsDiv = document.getElementById('api-resultados');
        resultsDiv.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i> Carregando página ' + page + '...</div>';
        
        try {
            const response = await fetch(`api/discogs_buscar.php?q=${encodeURIComponent(this.currentQuery)}&page=${page}`);
            const data = await response.json();
            
            if (data.success) {
                this.searchResults = data.resultados;
                this.displayResults(data.resultados);
            }
        } catch (error) {
            console.error('Erro ao carregar página:', error);
            this.showMessage('Erro ao carregar página', 'erro');
        }
    }
    
    // Mostrar modal de detalhes
    showDetailsModal(detalhes) {
        const modalHtml = `
            <div class="modal-overlay" id="discogs-modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>${this.escapeHtml(detalhes.title || 'Detalhes')}</h3>
                        <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">&times;</button>
                    </div>
                    <div class="modal-body">
                        ${detalhes.cover_image ? `
                            <div style="text-align: center; margin-bottom: 1rem;">
                                <img src="${detalhes.cover_image}" alt="Capa" style="max-width: 200px; max-height: 200px;">
                            </div>
                        ` : ''}
                        
                        <div class="details-grid">
                            <div><strong>Artista:</strong> ${this.escapeHtml(detalhes.artists || detalhes.artist || 'N/A')}</div>
                            <div><strong>Ano:</strong> ${detalhes.year || 'N/A'}</div>
                            <div><strong>Gravadora:</strong> ${this.escapeHtml(detalhes.labels ? detalhes.labels.map(l => l.name).join(', ') : detalhes.label || 'N/A')}</div>
                            <div><strong>Formato:</strong> ${this.escapeHtml(detalhes.formats ? detalhes.formats.map(f => f.name + (f.descriptions ? ' (' + f.descriptions.join(', ') + ')' : '')).join(', ') : detalhes.format || 'N/A')}</div>
                            <div><strong>Gênero:</strong> ${this.escapeHtml(detalhes.genres ? detalhes.genres.join(', ') : detalhes.genre || 'N/A')}</div>
                            <div><strong>Estilo:</strong> ${this.escapeHtml(detalhes.styles ? detalhes.styles.join(', ') : detalhes.style || 'N/A')}</div>
                        </div>
                        
                        ${detalhes.tracklist ? `
                            <div style="margin-top: 1rem;">
                                <h4>Faixas:</h4>
                                <ol style="padding-left: 1.5rem; max-height: 200px; overflow-y: auto;">
                                    ${detalhes.tracklist.map(track => `
                                        <li>${this.escapeHtml(track.title || track)} ${track.duration ? `(${track.duration})` : ''}</li>
                                    `).join('')}
                                </ol>
                            </div>
                        ` : ''}
                    </div>
                    <div class="modal-footer">
                        <button class="btn-primary" onclick="discogs.selectFromDetails(${JSON.stringify(detalhes).replace(/"/g, '&quot;')})">
                            <i class="fas fa-check"></i> Usar estes dados
                        </button>
                        <button class="btn-secondary" onclick="this.closest('.modal-overlay').remove()">
                            Fechar
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        // Remover modal existente
        const existingModal = document.getElementById('discogs-modal');
        if (existingModal) existingModal.remove();
        
        // Adicionar novo modal
        document.body.insertAdjacentHTML('beforeend', modalHtml);
    }
    
    // Selecionar dados do modal
    selectFromDetails(detalhes) {
        // Preencher campos com dados detalhados
        document.getElementById('artista_banda').value = detalhes.artists || detalhes.artist || '';
        document.getElementById('nome').value = detalhes.title || '';
        document.getElementById('ano_lancamento').value = detalhes.year || '';
        
        // Extrair gravadora
        if (detalhes.labels && detalhes.labels.length > 0) {
            document.getElementById('gravadora').value = detalhes.labels.map(l => l.name).join(', ');
        } else if (detalhes.label) {
            document.getElementById('gravadora').value = detalhes.label;
        }
        
        // Detectar tipo de mídia
        if (detalhes.formats && detalhes.formats.length > 0) {
            const formatText = detalhes.formats.map(f => f.name).join(' ').toLowerCase();
            const tipoSelect = document.getElementById('tipo_midia');
            
            if (formatText.includes('cd')) {
                tipoSelect.value = 'CD';
            } else if (formatText.includes('vinyl') || formatText.includes('lp')) {
                tipoSelect.value = 'LP';
            } else if (formatText.includes('box')) {
                tipoSelect.value = 'BoxSet';
            }
        }
        
        // Fechar modal
        const modal = document.getElementById('discogs-modal');
        if (modal) modal.remove();
        
        // Mostrar mensagem
        this.showMessage(`Dados detalhados de "${detalhes.title}" preenchidos!`, 'sucesso');
    }
    
    // Utilitários
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    truncateText(text, maxLength) {
        if (!text) return '';
        if (text.length <= maxLength) return text;
        return text.substring(0, maxLength) + '...';
    }
    
    showMessage(text, type = 'info') {
        // Usar o sistema de mensagens existente ou criar um simples
        const messageDiv = document.createElement('div');
        messageDiv.className = `alert alert-${type}`;
        messageDiv.innerHTML = `
            <div style="padding: 10px; margin: 10px 0; border-radius: 4px; 
                       background-color: ${type === 'sucesso' ? '#d4edda' : type === 'erro' ? '#f8d7da' : '#fff3cd'};
                       color: ${type === 'sucesso' ? '#155724' : type === 'erro' ? '#721c24' : '#856404'};
                       border: 1px solid ${type === 'sucesso' ? '#c3e6cb' : type === 'erro' ? '#f5c6cb' : '#ffeaa7'};">
                ${text}
            </div>
        `;
        
        const container = document.querySelector('.main-content');
        if (container) {
            container.insertBefore(messageDiv, container.firstChild);
            
            // Remover após 5 segundos
            setTimeout(() => {
                if (messageDiv.parentNode) {
                    messageDiv.parentNode.removeChild(messageDiv);
                }
            }, 5000);
        }
    }
}

// Criar instância global
const discogs = new DiscogsIntegration();

// Funções globais para chamadas no HTML
function executarBuscaAPI() {
    const query = document.getElementById('api-busca').value;
    if (query) {
        discogs.search(query);
    }
}

function buscarViaAPI() {
    document.getElementById('api-pesquisa').style.display = 'block';
    document.getElementById('api-busca').focus();
}

function mostrarFormManual() {
    document.getElementById('api-pesquisa').style.display = 'none';
}
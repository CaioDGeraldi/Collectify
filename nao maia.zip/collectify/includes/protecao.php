<?php
// includes/protecao.php - Versão corrigida

// Verificar se a sessão já foi iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function verificarLogin() {
    if (!isset($_SESSION['usuario_id'])) {
        $_SESSION['erro'] = "Acesso negado. Faça login primeiro.";
        header("Location: ../login.html");
        exit();
    }
}

function isAdmin() {
    return isset($_SESSION['tipo_usuario']) && $_SESSION['tipo_usuario'] === 'admin';
}




function verificarAdmin() {
    if (!isAdmin()) {
        $_SESSION['erro'] = "Acesso restrito para administradores.";
        header("Location: ../dashboard.php");
        exit();
    }
}
?>
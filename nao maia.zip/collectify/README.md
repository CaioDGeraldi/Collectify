# Collectify - Sistema de Gerenciamento de Coleções

## Descrição
Sistema web para organização e gerenciamento de coleções de mídias físicas (CDs, LPs, BoxSets, etc).

## Tecnologias
- HTML5, CSS3, JavaScript (ES6+)
- PHP 7.4+
- MySQL 5.7+
- Apache/Nginx

## Instalação

### 1. Requisitos
- PHP 7.4 ou superior
- MySQL 5.7 ou superior
- Apache com mod_rewrite habilitado
- Extensão PDO para PHP

### 2. Configuração do Banco de Dados
```bash
mysql -u root -p < sql/collectify_db.sql
<?php
require_once 'includes/protecao.php';
require_once 'includes/mensagens.php';
verificarLogin();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Item - Collectify</title>
    <link rel="stylesheet" href="assets/css/estilos.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- CSS para a integração Discogs -->
    <style>
    .discogs-results {
        margin-top: 1rem;
        border: 1px solid #ddd;
        border-radius: 8px;
        overflow: hidden;
    }

    .discogs-item {
        border-bottom: 1px solid #eee;
        padding: 1rem;
        transition: background-color 0.2s;
    }

    .discogs-item:hover {
        background-color: #f9f9f9;
    }

    .discogs-item:last-child {
        border-bottom: none;
    }

    .discogs-item-content {
        display: flex;
        gap: 1rem;
        align-items: flex-start;
    }

    .discogs-thumb {
        flex-shrink: 0;
        width: 80px;
        height: 80px;
        background: #f0f0f0;
        border-radius: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
    }

    .discogs-thumb img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .discogs-thumb.placeholder {
        color: #999;
        font-size: 2rem;
    }

    .discogs-info {
        flex: 1;
    }

    .discogs-info h4 {
        margin: 0 0 0.5rem 0;
        color: #333;
    }

    .discogs-info .artist {
        margin: 0 0 0.5rem 0;
        color: #666;
    }

    .discogs-meta {
        display: flex;
        gap: 1rem;
        margin-bottom: 0.75rem;
        flex-wrap: wrap;
    }

    .discogs-meta span {
        display: inline-flex;
        align-items: center;
        gap: 0.25rem;
        font-size: 0.9rem;
        color: #777;
        background: #f5f5f5;
        padding: 0.25rem 0.5rem;
        border-radius: 3px;
    }

    .discogs-actions {
        display: flex;
        gap: 0.5rem;
    }

    .discogs-pagination {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 1rem;
        padding: 1rem;
        background: #f9f9f9;
        border-top: 1px solid #eee;
    }

    .loading, .empty-state, .error-state {
        text-align: center;
        padding: 2rem;
        color: #666;
    }

    /* Modal styles */
    .modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1000;
    }

    .modal-content {
        background: white;
        border-radius: 8px;
        max-width: 600px;
        width: 90%;
        max-height: 80vh;
        overflow-y: auto;
    }

    .modal-header {
        padding: 1rem;
        border-bottom: 1px solid #eee;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .modal-close {
        background: none;
        border: none;
        font-size: 1.5rem;
        cursor: pointer;
        color: #666;
    }

    .modal-body {
        padding: 1rem;
    }

    .modal-footer {
        padding: 1rem;
        border-top: 1px solid #eee;
        text-align: right;
    }

    .details-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
        gap: 0.5rem;
    }

    @media (max-width: 768px) {
        .discogs-item-content {
            flex-direction: column;
        }
        
        .discogs-thumb {
            width: 100%;
            height: 150px;
        }
    }
    </style>
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="logo">
                <i class="fas fa-compact-disc"></i>
                <h1>Collectify</h1>
            </div>
            <ul class="nav-links">
                <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="cadastrar_item.php" class="active"><i class="fas fa-plus-circle"></i> Novo Item</a></li>
                <li><a href="api/logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
            </ul>
        </nav>
    </header>

    <div class="dashboard-container">
        <aside class="sidebar">
            <ul>
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="cadastrar_item.php" class="active"><i class="fas fa-plus-circle"></i> Novo Item</a></li>
                <li><a href="pesquisar_item.php"><i class="fas fa-search"></i> Pesquisar</a></li>
                <li><a href="minhas_colecoes.php"><i class="fas fa-folder"></i> Minhas Coleções</a></li>
                <li><a href="lista_desejos.php"><i class="fas fa-heart"></i> Lista de Desejos</a></li>
            </ul>
        </aside>

        <main class="main-content">
            <h2><i class="fas fa-plus-circle"></i> Cadastrar Novo Item</h2>
            
            <?php echo exibirMensagens(); ?>
            
            <div class="form-container" style="max-width: 800px;">
                <div style="margin-bottom: 2rem;">
                    <button type="button" class="btn-primary" onclick="buscarViaAPI()">
                        <i class="fas fa-search"></i> Buscar via Discogs
                    </button>
                    <button type="button" class="btn-secondary" onclick="mostrarFormManual()">
                        <i class="fas fa-edit"></i> Cadastro Manual
                    </button>
                </div>
                
                <div id="api-pesquisa" style="display: none; margin-bottom: 2rem;">
                    <div class="form-group">
                        <label for="api-busca"><i class="fas fa-search"></i> Buscar na Discogs:</label>
                        <div style="display: flex; gap: 10px;">
                            <input type="text" id="api-busca" class="form-control" 
                                   placeholder="Digite nome do álbum ou artista...">
                            <button type="button" class="btn-primary" onclick="executarBuscaAPI()">
                                <i class="fas fa-search"></i> Buscar
                            </button>
                        </div>
                    </div>
                    
                    <div id="api-resultados" style="margin-top: 1rem;"></div>
                </div>
                
                <form id="formItem" action="api/cadastrar_item.php" method="POST" enctype="multipart/form-data">
                    <!-- Adicionar campo oculto para URL da imagem -->
                    <input type="hidden" id="imagem_url" name="imagem_url">
                    
                    <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                        <div class="form-group">
                            <label for="artista_banda">* Artista/Banda:</label>
                            <input type="text" id="artista_banda" name="artista_banda" 
                                   class="form-control" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="nome">* Nome do Álbum:</label>
                            <input type="text" id="nome" name="nome" 
                                   class="form-control" required>
                        </div>
                    </div>
                    
                    <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                        <div class="form-group">
                            <label for="ano_lancamento">* Ano de Lançamento:</label>
                            <input type="number" id="ano_lancamento" name="ano_lancamento" 
                                   class="form-control" required min="1900" max="2024">
                        </div>
                        
                        <div class="form-group">
                            <label for="tipo_midia">* Tipo de Mídia:</label>
                            <select id="tipo_midia" name="tipo_midia" class="form-control" required>
                                <option value="">Selecione...</option>
                                <option value="CD">CD</option>
                                <option value="LP">LP</option>
                                <option value="BoxSet">BoxSet</option>
                                <option value="Livro">Livro</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                        <div class="form-group">
                            <label for="gravadora">Gravadora:</label>
                            <input type="text" id="gravadora" name="gravadora" class="form-control">
                        </div>
                        
                        <div class="form-group">
                            <label for="origem">Origem:</label>
                            <input type="text" id="origem" name="origem" class="form-control">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="qualidade">Qualidade:</label>
                        <input type="text" id="qualidade" name="qualidade" class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label>Características Especiais:</label>
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px;">
                            <label style="display: flex; align-items: center; gap: 5px;">
                                <input type="checkbox" name="encarte" value="1">
                                <span>Encarte</span>
                            </label>
                            <label style="display: flex; align-items: center; gap: 5px;">
                                <input type="checkbox" name="obi_coa" value="1">
                                <span>OBI/COA</span>
                            </label>
                            <label style="display: flex; align-items: center; gap: 5px;">
                                <input type="checkbox" name="hypersticker" value="1">
                                <span>HyperSticker</span>
                            </label>
                            <label style="display: flex; align-items: center; gap: 5px;">
                                <input type="checkbox" name="boxset" value="1">
                                <span>BoxSet</span>
                            </label>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Itens Prioritários (RNF009):</label>
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px;">
                            <label style="display: flex; align-items: center; gap: 5px;">
                                <input type="checkbox" name="autografado" value="1">
                                <span>Autografado</span>
                            </label>
                            <label style="display: flex; align-items: center; gap: 5px;">
                                <input type="checkbox" name="primeira_edicao" value="1">
                                <span>Primeira Edição</span>
                            </label>
                            <label style="display: flex; align-items: center; gap: 5px;">
                                <input type="checkbox" name="limitado" value="1">
                                <span>Edição Limitada</span>
                            </label>
                            <label style="display: flex; align-items: center; gap: 5px;">
                                <input type="checkbox" name="importado" value="1">
                                <span>Importado</span>
                            </label>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="observacoes">Observações:</label>
                        <textarea id="observacoes" name="observacoes" 
                                  class="form-control" rows="3"></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="imagem">Imagem do Item (opcional):</label>
                        <input type="file" id="imagem" name="imagem" 
                               class="form-control" accept="image/*">
                        <small class="form-text text-muted">Se não enviar imagem, poderá ser usada a capa da Discogs.</small>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn-primary">
                            <i class="fas fa-save"></i> Cadastrar Item
                        </button>
                        <button type="button" class="btn-secondary" onclick="window.history.back()">
                            <i class="fas fa-times"></i> Cancelar
                        </button>
                    </div>
                </form>
            </div>
        </main>
    </div>

    <script src="assets/js/mensagens.js"></script>
    <script src="assets/js/validacao_formulario.js"></script>
    <!-- REMOVA a linha abaixo se existir: <script src="assets/js/api_integracao.js"></script> -->
    <script src="assets/js/discogs_integracao.js"></script>
    
    <script>
    // Adicionar evento de tecla Enter no campo de busca
    document.getElementById('api-busca').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            executarBuscaAPI();
        }
    });

    // Prevenir reenvio do formulário
    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    }
    </script>
</body>
</html>
<?php
require_once 'includes/protecao.php';
require_once 'includes/conexao.php';
require_once 'includes/mensagens.php';
verificarLogin();

// -----------------------------
// 1. VALIDAR ID
// -----------------------------
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['erro'] = "Item não especificado.";
    header("Location: pesquisar_item.php");
    exit();
}

$itemId = intval($_GET['id']);
$userId = $_SESSION['usuario_id'];

$pdo = getConnection();

// -----------------------------
// 2. SALVAR ALTERAÇÕES
// -----------------------------
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $artista_banda   = $_POST['artista_banda'];
    $nome            = $_POST['nome'];
    $ano_lancamento  = $_POST['ano_lancamento'];
    $gravadora       = $_POST['gravadora'];
    $tipo_midia      = $_POST['tipo_midia'];
    $origem          = $_POST['origem'];
    $edicao          = $_POST['edicao'];
    $qualidade       = $_POST['qualidade'];
    $codigo          = $_POST['codigo'];
    $observacoes     = $_POST['observacoes'];

    $autografado     = isset($_POST['autografado']) ? 1 : 0;
    $primeira_edicao = isset($_POST['primeira_edicao']) ? 1 : 0;
    $importado       = isset($_POST['importado']) ? 1 : 0;
    $limitado        = isset($_POST['limitado']) ? 1 : 0;
    $encarte         = isset($_POST['encarte']) ? 1 : 0;
    $obi_coa         = isset($_POST['obi_coa']) ? 1 : 0;
    $boxset          = isset($_POST['boxset']) ? 1 : 0;
    $hypersticker    = isset($_POST['hypersticker']) ? 1 : 0;

    // -----------------------------
    // UPLOAD DE IMAGEM
    // -----------------------------
    $imagemAtual = $_POST['imagem_atual'];
    $novaImagem = $imagemAtual;

    if (!empty($_FILES['imagem']['name'])) {

        $ext = pathinfo($_FILES['imagem']['name'], PATHINFO_EXTENSION);
        $novoNome = uniqid() . "." . $ext;

        $destino = "assets/uploads/" . $novoNome;

        if (move_uploaded_file($_FILES['imagem']['tmp_name'], $destino)) {
            $novaImagem = $novoNome;
        }
    }

    // -----------------------------
    // UPDATE
    // -----------------------------
    try {
        $sql = "UPDATE itens SET 
                    artista_banda=?, nome=?, ano_lancamento=?, gravadora=?, tipo_midia=?,
                    origem=?, edicao=?, qualidade=?, codigo=?, observacoes=?, imagem=?,
                    autografado=?, primeira_edicao=?, importado=?, limitado=?,
                    encarte=?, obi_coa=?, boxset=?, hypersticker=?
                WHERE id=? AND usuario_id=?";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $artista_banda, $nome, $ano_lancamento, $gravadora, $tipo_midia,
            $origem, $edicao, $qualidade, $codigo, $observacoes, $novaImagem,
            $autografado, $primeira_edicao, $importado, $limitado,
            $encarte, $obi_coa, $boxset, $hypersticker,
            $itemId, $userId
        ]);

        $_SESSION['sucesso'] = "Item atualizado com sucesso.";
        header("Location: visualizar_item.php?id=" . $itemId);
        exit();

    } catch (Exception $e) {
        $_SESSION['erro'] = "Erro ao atualizar item: " . $e->getMessage();
        header("Location: editar_item.php?id=" . $itemId);
        exit();
    }
}

// -----------------------------
// 3. CARREGAR DADOS DO ITEM
// -----------------------------
$sql = "SELECT * FROM itens WHERE id = ? AND usuario_id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$itemId, $userId]);
$item = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$item) {
    $_SESSION['erro'] = "Item não encontrado.";
    header("Location: pesquisar_item.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Item - Collectify</title>
    <link rel="stylesheet" href="assets/css/estilos.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        form input, form textarea, form select {
            width: 100%;
            padding: 10px;
            margin-bottom: 12px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }

        .checkbox-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 5px 15px;
            margin-bottom: 20px;
        }

        .btn {
            padding: 12px 20px;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            text-decoration: none;
            font-weight: 600;
        }

        .btn-primary { background: #3498db; color: #fff; }
        .btn-secondary { background: #7f8c8d; color: #fff; }

        .btn-primary:hover { background: #2980b9; }
    </style>
</head>
<body>


<div class="dashboard-container">
    <main class="main-content">

        <h2><i class="fas fa-edit"></i> Editar Item</h2>
        <?php echo exibirMensagens(); ?>

        <form method="POST" enctype="multipart/form-data">

            <label>Artista/Banda</label>
            <input type="text" name="artista_banda" value="<?= htmlspecialchars($item['artista_banda']) ?>" required>

            <label>Nome do Álbum</label>
            <input type="text" name="nome" value="<?= htmlspecialchars($item['nome']) ?>" required>

            <label>Ano de Lançamento</label>
            <input type="number" name="ano_lancamento" value="<?= $item['ano_lancamento'] ?>">

            <label>Gravadora</label>
            <input type="text" name="gravadora" value="<?= htmlspecialchars($item['gravadora']) ?>">

            <label>Tipo de Mídia</label>
            <select name="tipo_midia">
                <option <?= $item['tipo_midia']=='CD'?'selected':'' ?>>CD</option>
                <option <?= $item['tipo_midia']=='Vinil'?'selected':'' ?>>Vinil</option>
                <option <?= $item['tipo_midia']=='K7'?'selected':'' ?>>K7</option>
                <option <?= $item['tipo_midia']=='DVD'?'selected':'' ?>>DVD</option>
            </select>

            <label>Origem</label>
            <input type="text" name="origem" value="<?= htmlspecialchars($item['origem']) ?>">

            <label>Edição</label>
            <input type="text" name="edicao" value="<?= htmlspecialchars($item['edicao']) ?>">

            <label>Qualidade</label>
            <input type="text" name="qualidade" value="<?= htmlspecialchars($item['qualidade']) ?>">

            <label>Código</label>
            <input type="text" name="codigo" value="<?= htmlspecialchars($item['codigo']) ?>">

            <label>Observações</label>
            <textarea name="observacoes"><?= htmlspecialchars($item['observacoes']) ?></textarea>

            <h3>Características</h3>

            <div class="checkbox-grid">
                <label><input type="checkbox" name="autografado" <?= $item['autografado']?'checked':'' ?>> Autografado</label>
                <label><input type="checkbox" name="primeira_edicao" <?= $item['primeira_edicao']?'checked':'' ?>> Primeira Edição</label>
                <label><input type="checkbox" name="importado" <?= $item['importado']?'checked':'' ?>> Importado</label>
                <label><input type="checkbox" name="limitado" <?= $item['limitado']?'checked':'' ?>> Limitado</label>
                <label><input type="checkbox" name="encarte" <?= $item['encarte']?'checked':'' ?>> Encarte</label>
                <label><input type="checkbox" name="obi_coa" <?= $item['obi_coa']?'checked':'' ?>> OBI/COA</label>
                <label><input type="checkbox" name="boxset" <?= $item['boxset']?'checked':'' ?>> Box Set</label>
                <label><input type="checkbox" name="hypersticker" <?= $item['hypersticker']?'checked':'' ?>> Hyper Sticker</label>
            </div>

            <label>Imagem Atual:</label><br>
            <img src="assets/uploads/<?= htmlspecialchars($item['imagem']) ?>" style="max-width: 200px; border-radius: 6px;"><br><br>

            <label>Alterar Imagem (opcional)</label>
            <input type="file" name="imagem">

            <input type="hidden" name="imagem_atual" value="<?= $item['imagem'] ?>">

            <button type="submit" class="btn btn-primary">Salvar Alterações</button>
            <a href="detalhes_item.php?id=<?= $itemId ?>" class="btn btn-secondary">Cancelar</a>

        </form>
    </main>
</div>

</body>
</html>

<?php
require_once 'includes/protecao.php';
require_once 'includes/conexao.php';
require_once 'includes/mensagens.php';

verificarLogin();
protegerAdmin();

// Verificar se foi passado um ID
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['erro'] = "Item não especificado.";
    header("Location: pesquisar_item.php");
    exit();
}

$itemId = intval($_GET['id']);
$userId = $_SESSION['usuario_id'];

try {
    $pdo = getConnection();

    // 1. Primeiro verificar se o item pertence ao usuário
    $sql_check = "SELECT id FROM itens WHERE id = ? AND usuario_id = ?";
    $stmt = $pdo->prepare($sql_check);
    $stmt->execute([$itemId, $userId]);
    $item = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$item) {
        $_SESSION['erro'] = "Você não tem permissão para excluir este item.";
        header("Location: pesquisar_item.php");
        exit();
    }

    // 2. Excluir da tabela itens (as outras tabelas apagam automaticamente por ON DELETE CASCADE)
    $sql_delete = "DELETE FROM itens WHERE id = ? AND usuario_id = ?";
    $stmt = $pdo->prepare($sql_delete);
    $stmt->execute([$itemId, $userId]);

    $_SESSION['sucesso'] = "Item excluído com sucesso!";
    header("Location: dashboard.php");
    exit();

} catch (Exception $e) {
    $_SESSION['erro'] = "Erro ao excluir o item: " . $e->getMessage();
    header("Location: dashboard.php");
    exit();
}

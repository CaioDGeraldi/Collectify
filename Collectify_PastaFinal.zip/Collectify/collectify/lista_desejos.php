<?php
require_once 'includes/protecao.php';
require_once 'includes/mensagens.php';
verificarLogin();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Desejos - Collectify</title>
    <link rel="stylesheet" href="assets/css/estilos.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="logo">
                <i class="fas fa-compact-disc"></i>
                <h1>Collectify</h1>
            </div>
            <ul class="nav-links">
                <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="lista_desejos.php" class="active"><i class="fas fa-heart"></i> Lista de Desejos</a></li>
                <li><a href="api/logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
            </ul>
        </nav>
    </header>

    <div class="dashboard-container">
        <aside class="sidebar">
            <ul>
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="cadastrar_item.php"><i class="fas fa-plus-circle"></i> Novo Item</a></li>
                <li><a href="pesquisar_item.php"><i class="fas fa-search"></i> Pesquisar</a></li>
                <li><a href="minhas_colecoes.php"><i class="fas fa-folder"></i> Minhas Coleções</a></li>
                <li><a href="lista_desejos.php" class="active"><i class="fas fa-heart"></i> Lista de Desejos</a></li>
            </ul>
        </aside>

        <main class="main-content">
            <h2><i class="fas fa-heart"></i> Minha Lista de Desejos</h2>
            
            <?php echo exibirMensagens(); ?>
            
            <div id="lista-desejos" class="itens-grid">
                <!-- Itens da lista de desejos serão carregados via JavaScript -->
            </div>
        </main>
    </div>

    <script src="assets/js/mensagens.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Carregando lista de desejos...');
            carregarListaDesejos();
        });
        
        function carregarListaDesejos() {
            fetch('api/lista_desejos.php')
                .then(response => {
                    console.log('Status resposta:', response.status);
                    // Verificar se é JSON
                    const contentType = response.headers.get('content-type');
                    if (!contentType || !contentType.includes('application/json')) {
                        return response.text().then(text => {
                            console.error('Resposta não é JSON:', text.substring(0, 200));
                            throw new Error('Resposta não é JSON');
                        });
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('Dados recebidos:', data);
                    const container = document.getElementById('lista-desejos');
                    
                    if (data.success && data.itens && data.itens.length > 0) {
                        container.innerHTML = data.itens.map(item => {
                            console.log('Item:', item);
                            // CORREÇÃO DO CAMINHO DA IMAGEM
                            const imagemHtml = item.imagem 
                                ? `<img src="assets/uploads/${item.imagem}" alt="${item.nome}" style="width: 100%; height: 100%; object-fit: cover;">`
                                : `<i class="fas fa-heart" style="color: #ff6b6b; font-size: 4rem;"></i>`;
                            
                            return `
                            <div class="item-card">
                                <div class="item-image" style="background-color: #666; height: 150px; display: flex; align-items: center; justify-content: center; overflow: hidden;">
                                    ${imagemHtml}
                                </div>
                                <div class="item-info">
                                    <h3>${escapeHtml(item.nome || 'Sem nome')}</h3>
                                    <p class="item-meta">${escapeHtml(item.artista_banda || 'Artista desconhecido')} • ${item.ano_lancamento || 'N/A'}</p>
                                    <p class="item-meta">Tipo: ${item.tipo_midia || 'Desconhecido'}</p>
                                    <div class="item-actions">
                                        <a href="detalhes_item.php?id=${item.id}" class="btn-primary btn-sm">
                                            <i class="fas fa-eye"></i> Ver
                                        </a>
                                        <button class="btn-danger btn-sm" onclick="removerDesejo(${item.id})">
                                            <i class="fas fa-trash"></i> Remover
                                        </button>
                                    </div>
                                </div>
                            </div>`;
                        }).join('');
                    } else {
                        container.innerHTML = `
                            <div style="grid-column: 1 / -1; text-align: center; padding: 3rem; color: #666;">
                                <i class="fas fa-heart" style="font-size: 3rem; margin-bottom: 1rem;"></i>
                                <h3>Sua lista de desejos está vazia</h3>
                                <p>Adicione itens à lista de desejos clicando no botão "Desejo" nos itens.</p>
                            </div>`;
                    }
                })
                .catch(error => {
                    console.error('Erro ao carregar lista de desejos:', error);
                    const container = document.getElementById('lista-desejos');
                    container.innerHTML = `
                        <div style="grid-column: 1 / -1; text-align: center; padding: 2rem; color: #e74c3c;">
                            <i class="fas fa-exclamation-triangle" style="font-size: 2rem; margin-bottom: 1rem;"></i>
                            <p>Erro ao carregar lista de desejos.</p>
                            <p>Verifique o console (F12) para detalhes.</p>
                        </div>`;
                });
        }
        
        function removerDesejo(itemId) {
            if (confirm('Remover item da lista de desejos?')) {
                fetch('api/remover_desejo.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `item_id=${itemId}`
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Usar sistema de mensagens existente ou mostrar alerta
                        if (typeof mostrarMensagem === 'function') {
                            mostrarMensagem('sucesso', data.message);
                        } else {
                            alert(data.message);
                        }
                        carregarListaDesejos();
                    } else {
                        alert('Erro: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Erro:', error);
                    alert('Erro ao remover item da lista de desejos');
                });
            }
        }
        
        function verDetalhes(itemId) {
            window.location.href = `detalhes_item.php?id=${itemId}`;
        }
        
        // Função utilitária
        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
    </script>
</body>
</html>
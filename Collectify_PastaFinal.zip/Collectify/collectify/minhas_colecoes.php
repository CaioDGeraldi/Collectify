<?php
require_once 'includes/protecao.php';
require_once 'includes/mensagens.php';
verificarLogin();

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Minhas Coleções - Collectify</title>
    <link rel="stylesheet" href="assets/css/estilos.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="logo">
                <i class="fas fa-compact-disc"></i>
                <h1>Collectify</h1>
            </div>
            <ul class="nav-links">
                <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="minhas_colecoes.php" class="active"><i class="fas fa-folder"></i> Minhas Coleções</a></li>
                <li><a href="api/logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
            </ul>
        </nav>
    </header>

    <div class="dashboard-container">
        <aside class="sidebar">
            <ul>
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="cadastrar_item.php"><i class="fas fa-plus-circle"></i> Novo Item</a></li>
                <li><a href="pesquisar_item.php"><i class="fas fa-search"></i> Pesquisar</a></li>
                <li><a href="minhas_colecoes.php" class="active"><i class="fas fa-folder"></i> Minhas Coleções</a></li>
                <li><a href="lista_desejos.php"><i class="fas fa-heart"></i> Lista de Desejos</a></li>
            </ul>
        </aside>

        <main class="main-content">
            <h2><i class="fas fa-folder"></i> Minhas Coleções</h2>
            
            <?php echo exibirMensagens(); ?>
            
            <?php if (isAdmin()): ?>
<div style="margin-bottom: 2rem;">
    <button class="btn-primary" onclick="novaColecao()">
        <i class="fas fa-plus"></i> Nova Coleção
    </button>
</div>
<?php endif; ?>

            
            <div id="form-nova-colecao" style="display: none; margin-bottom: 2rem;">
                <div class="form-container" style="max-width: 500px;">
                    <h3>Nova Coleção</h3>
                    <form id="formColecao" onsubmit="criarColecao(event)">
                        <div class="form-group">
                            <label for="nome_colecao">Nome da Coleção:</label>
                            <input type="text" id="nome_colecao" class="form-control" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="categoria_colecao">Categoria:</label>
                            <select id="categoria_colecao" class="form-control" required>
                                <option value="">Selecione...</option>
                                <option value="genero">Gênero Musical</option>
                                <option value="favoritas">Favoritas</option>
                                <option value="tipo_item">Tipo de Item</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="descricao_colecao">Descrição:</label>
                            <textarea id="descricao_colecao" class="form-control" rows="3"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" class="btn-primary">Criar Coleção</button>
                            <button type="button" class="btn-secondary" onclick="cancelarColecao()">Cancelar</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <div id="lista-colecoes" class="itens-grid">
                <!-- Coleções serão carregadas via JavaScript -->
            </div>
        </main>
    </div>

    <script src="assets/js/mensagens.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            carregarColecoes();
        });
        
        function carregarColecoes() {
            fetch('api/colecoes.php')
                .then(response => response.json())
                .then(data => {
                    const container = document.getElementById('lista-colecoes');
                    
                    if (data.success && data.colecoes.length > 0) {
                        container.innerHTML = data.colecoes.map(colecao => `
                            <div class="item-card">
                                <div class="item-image" style="background-color: #666;">
                                    <i class="fas fa-folder-open" style="font-size: 4rem; color: white;"></i>
                                </div>
                                <div class="item-info">
                                    <h3>${colecao.nome}</h3>
                                    <p class="item-meta">Categoria: ${colecao.categoria}</p>
                                    ${colecao.descricao ? `<p>${colecao.descricao}</p>` : ''}
                                    <p class="item-meta">Itens: ${colecao.total_itens || 0}</p>
                                    <div class="item-actions">
                                        <button class="btn-primary btn-sm" onclick="verColecao(${colecao.id})">
                                            <i class="fas fa-eye"></i> Ver
                                        </button>
                                        <button class="btn-secondary btn-sm" onclick="editarColecao(${colecao.id})">
                                            <i class="fas fa-edit"></i> Editar
                                        </button>
                                    </div>
                                </div>
                            </div>
                        `).join('');
                    } else {
                        container.innerHTML = '<p>Você ainda não tem coleções. Crie sua primeira coleção!</p>';
                    }
                })
                .catch(error => {
                    console.error('Erro ao carregar coleções:', error);
                });
        }
        
        function novaColecao() {
            document.getElementById('form-nova-colecao').style.display = 'block';
        }
        
        function cancelarColecao() {
            document.getElementById('form-nova-colecao').style.display = 'none';
            document.getElementById('formColecao').reset();
        }
        
        function criarColecao(event) {
    event.preventDefault();
    
    const nome = document.getElementById('nome_colecao').value;
    const categoria = document.getElementById('categoria_colecao').value;
    const descricao = document.getElementById('descricao_colecao').value;
    
    console.log('Enviando dados:', { nome, categoria, descricao });
    
    // Mostrar loading
    const btn = document.querySelector('#formColecao button[type="submit"]');
    const originalText = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Criando...';
    btn.disabled = true;
    
    // IMPORTANTE: Usar URLSearchParams para enviar dados
    const params = new URLSearchParams();
    params.append('nome', nome);
    params.append('categoria', categoria);
    params.append('descricao', descricao);
    
    fetch('api/criar_colecao.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: params.toString(),
        credentials: 'include'  // ← ESSENCIAL: envia cookies da sessão
    })
    .then(response => {
        console.log('Status da resposta:', response.status);
        return response.json();
    })
    .then(data => {
        console.log('Resposta da API:', data);
        
        // Restaurar botão
        btn.innerHTML = originalText;
        btn.disabled = false;
        
        if (data.success) {
            mostrarMensagem('sucesso', data.message);
            cancelarColecao();
            carregarColecoes();
        } else {
            mostrarMensagem('erro', 'Erro: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Erro na requisição:', error);
        
        // Restaurar botão
        btn.innerHTML = originalText;
        btn.disabled = false;
        
        mostrarMensagem('erro', 'Erro de conexão com o servidor. Verifique o console (F12).');
    });
}
        
        function verColecao(colecaoId) {
            window.location.href = `api/detalhes_colecoes.php?id=${colecaoId}`;
        }
        
        function editarColecao(colecaoId) {
            // Implementar edição de coleção
            mostrarMensagem('info', 'Funcionalidade de edição em desenvolvimento');
        }
    </script>
</body>
</html>
<?php
require_once 'includes/protecao.php';
require_once 'includes/conexao.php';
require_once 'includes/mensagens.php';
verificarLogin();


// Verificar se foi passado um ID
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['erro'] = "Item não especificado.";
    header("Location: pesquisar_item.php");
    exit();
}

$itemId = intval($_GET['id']);
$userId = $_SESSION['usuario_id'];

// Buscar item no banco com TODOS os campos
try {
    $pdo = getConnection();
    
    $sql = "SELECT * FROM itens WHERE id = ? AND usuario_id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$itemId, $userId]);
    $item = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$item) {
        $_SESSION['erro'] = "Item não encontrado ou não pertence a você.";
        header("Location: pesquisar_item.php");
        exit();
    }
    
} catch (Exception $e) {
    $_SESSION['erro'] = "Erro ao carregar item: " . $e->getMessage();
    header("Location: pesquisar_item.php");
    exit();
}

// Função auxiliar para mostrar valores
function mostrarValor($valor) {
    return !empty($valor) ? htmlspecialchars($valor) : '<span style="color: #95a5a6; font-style: italic;">---</span>';
}

// Função para mostrar booleano
function mostrarBooleano($valor) {
    if ($valor == 1) {
        return '<span style="color: #27ae60; font-weight: bold;">✓ Sim</span>';
    } else {
        return '<span style="color: #e74c3c;">✗ Não</span>';
    }
}

// Função para mostrar imagem
function mostrarImagem($imagem) {
    if (!empty($imagem)) {
        // Verificar se a imagem já tem caminho completo
        if (strpos($imagem, 'http') === 0 || strpos($imagem, 'assets/') === 0) {
            $caminho = $imagem;
        } else {
            $caminho = 'assets/uploads/' . $imagem;
        }
        
        return '<img src="' . htmlspecialchars($caminho) . '" 
                     alt="Capa do álbum" 
                     style="max-width: 100%; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.15);"
                     onerror="this.src=\'assets/img/default-album.jpg\'; this.onerror=null;">';
    } else {
        return '<div style="background: #f8f9fa; padding: 3rem; text-align: center; border-radius: 8px; color: #6c757d;">
                  <i class="fas fa-compact-disc fa-3x"></i>
                  <p style="margin-top: 1rem;">Sem imagem disponível</p>
                </div>';
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($item['nome']); ?> - Collectify</title>
    <link rel="stylesheet" href="assets/css/estilos.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Estilos específicos para detalhes do item */
        .detail-grid {
            display: grid;
            grid-template-columns: 300px 1fr;
            gap: 2rem;
        }
        
        @media (max-width: 768px) {
            .detail-grid {
                grid-template-columns: 1fr;
            }
        }
        
        .info-section {
            background: white;
            padding: 1.5rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }
        
        .info-section h4 {
            color: #2c3e50;
            border-bottom: 2px solid #3498db;
            padding-bottom: 0.5rem;
            margin-top: 0;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .info-row {
            display: grid;
            grid-template-columns: 150px 1fr;
            padding: 8px 0;
            border-bottom: 1px solid #ecf0f1;
        }
        
        .info-row:last-child {
            border-bottom: none;
        }
        
        .info-label {
            font-weight: 600;
            color: #34495e;
        }
        
        .info-value {
            color: #2c3e50;
        }
        
        .characteristic-badge {
            display: inline-block;
            padding: 4px 10px;
            margin: 2px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
        }
        
        .characteristic-active {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .characteristic-inactive {
            background: #f8f9fa;
            color: #6c757d;
            border: 1px solid #e9ecef;
        }
        
        .image-container {
            position: sticky;
            top: 20px;
        }
        
        .btn-group {
            display: flex;
            gap: 10px;
            margin-top: 1rem;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 500;
            border: none;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background: #3498db;
            color: white;
        }
        
        .btn-primary:hover {
            background: #2980b9;
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
        }
        
        .btn-danger {
            background: #e74c3c;
            color: white;
        }
        
        .btn-danger:hover {
            background: #c0392b;
        }
        
        .btn-success {
            background: #27ae60;
            color: white;
        }
        
        .btn-success:hover {
            background: #219653;
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="logo">
                <i class="fas fa-compact-disc"></i>
                <h1>Collectify</h1>
            </div>
            <ul class="nav-links">
                <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="pesquisar_item.php"><i class="fas fa-search"></i> Pesquisar</a></li>
                <li><a href="api/logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
            </ul>
        </nav>
    </header>

    <div class="dashboard-container">
        <aside class="sidebar">
            <ul>
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="cadastrar_item.php"><i class="fas fa-plus-circle"></i> Novo Item</a></li>
                <li><a href="pesquisar_item.php"><i class="fas fa-search"></i> Pesquisar</a></li>
                <li><a href="minhas_colecoes.php"><i class="fas fa-folder"></i> Minhas Coleções</a></li>
                <li><a href="lista_desejos.php"><i class="fas fa-heart"></i> Lista de Desejos</a></li>
            </ul>
        </aside>

        <main class="main-content">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                <h2><i class="fas fa-info-circle"></i> Detalhes do Item</h2>
                <div class="btn-group">
                    <a href="pesquisar_item.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Voltar
                    </a>
                    <a href="editar_item.php?id=<?php echo $itemId; ?>" class="btn btn-primary">
                        <i class="fas fa-edit"></i> Editar
                    </a>
                </div>
            </div>
            
            <?php echo exibirMensagens(); ?>
            
            <div class="detail-grid">
                <!-- COLUNA DA ESQUERDA - IMAGEM -->
                <div class="image-container">
                    <div class="info-section">
                        <h4><i class="fas fa-image"></i> Capa do Álbum</h4>
                        <div style="text-align: center;">
                            <?php echo mostrarImagem($item['imagem']); ?>
                        </div>
                    </div>
                    
                    <div class="info-section">
                        <h4><i class="fas fa-qrcode"></i> Código</h4>
                        <div style="text-align: center; font-size: 1.2rem; font-weight: bold; color: #2c3e50;">
                            <?php echo mostrarValor($item['codigo']); ?>
                        </div>
                    </div>
                </div>
                
                <!-- COLUNA DA DIREITA - INFORMAÇÕES -->
                <div>
                    <!-- INFORMAÇÕES PRINCIPAIS -->
                    <div class="info-section">
                        <h4><i class="fas fa-info-circle"></i> Informações Principais</h4>
                        <div class="info-row">
                            <span class="info-label">Artista/Banda:</span>
                            <span class="info-value"><?php echo mostrarValor($item['artista_banda']); ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Nome do Álbum:</span>
                            <span class="info-value"><?php echo mostrarValor($item['nome']); ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Ano de Lançamento:</span>
                            <span class="info-value"><?php echo mostrarValor($item['ano_lancamento']); ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Gravadora:</span>
                            <span class="info-value"><?php echo mostrarValor($item['gravadora']); ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Tipo de Mídia:</span>
                            <span class="info-value">
                                <span style="display: inline-block; padding: 3px 10px; background: #3498db; color: white; border-radius: 4px; font-weight: 500;">
                                    <?php echo mostrarValor($item['tipo_midia']); ?>
                                </span>
                            </span>
                        </div>
                    </div>
                    
                    <!-- DETALHES TÉCNICOS -->
                    <div class="info-section">
                        <h4><i class="fas fa-cogs"></i> Detalhes Técnicos</h4>
                        <div class="info-row">
                            <span class="info-label">Origem:</span>
                            <span class="info-value"><?php echo mostrarValor($item['origem']); ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Edição:</span>
                            <span class="info-value"><?php echo mostrarValor($item['edicao']); ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Qualidade:</span>
                            <span class="info-value"><?php echo mostrarValor($item['qualidade']); ?></span>
                        </div>
                    </div>
                    
                    <!-- CARACTERÍSTICAS ESPECIAIS -->
                    <div class="info-section">
                        <h4><i class="fas fa-star"></i> Características Especiais</h4>
                        <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                            <span class="characteristic-badge <?php echo $item['autografado'] ? 'characteristic-active' : 'characteristic-inactive'; ?>">
                                <i class="fas fa-signature"></i> Autografado: <?php echo mostrarBooleano($item['autografado']); ?>
                            </span>
                            <span class="characteristic-badge <?php echo $item['primeira_edicao'] ? 'characteristic-active' : 'characteristic-inactive'; ?>">
                                <i class="fas fa-award"></i> Primeira Edição: <?php echo mostrarBooleano($item['primeira_edicao']); ?>
                            </span>
                            <span class="characteristic-badge <?php echo $item['importado'] ? 'characteristic-active' : 'characteristic-inactive'; ?>">
                                <i class="fas fa-globe"></i> Importado: <?php echo mostrarBooleano($item['importado']); ?>
                            </span>
                            <span class="characteristic-badge <?php echo $item['limitado'] ? 'characteristic-active' : 'characteristic-inactive'; ?>">
                                <i class="fas fa-hashtag"></i> Edição Limitada: <?php echo mostrarBooleano($item['limitado']); ?>
                            </span>
                            <span class="characteristic-badge <?php echo $item['encarte'] ? 'characteristic-active' : 'characteristic-inactive'; ?>">
                                <i class="fas fa-book"></i> Com Encarte: <?php echo mostrarBooleano($item['encarte']); ?>
                            </span>
                            <span class="characteristic-badge <?php echo $item['obi_coa'] ? 'characteristic-active' : 'characteristic-inactive'; ?>">
                                <i class="fas fa-sticky-note"></i> OBI/COA: <?php echo mostrarBooleano($item['obi_coa']); ?>
                            </span>
                            <span class="characteristic-badge <?php echo $item['boxset'] ? 'characteristic-active' : 'characteristic-inactive'; ?>">
                                <i class="fas fa-box"></i> Box Set: <?php echo mostrarBooleano($item['boxset']); ?>
                            </span>
                            <span class="characteristic-badge <?php echo $item['hypersticker'] ? 'characteristic-active' : 'characteristic-inactive'; ?>">
                                <i class="fas fa-sticker"></i> Hyper Sticker: <?php echo mostrarBooleano($item['hypersticker']); ?>
                            </span>
                        </div>
                    </div>
                    
                    <!-- OBSERVAÇÕES -->
                    <?php if (!empty($item['observacoes'])): ?>
                    <div class="info-section">
                        <h4><i class="fas fa-sticky-note"></i> Observações</h4>
                        <div style="background: #f8f9fa; padding: 1rem; border-radius: 6px; border-left: 4px solid #3498db; white-space: pre-wrap; line-height: 1.6;">
                            <?php echo htmlspecialchars($item['observacoes']); ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <!-- INFORMAÇÕES DO SISTEMA -->
                    <div class="info-section">
                        <h4><i class="fas fa-database"></i> Informações do Sistema</h4>
                        <div class="info-row">
                            <span class="info-label">Data de Cadastro:</span>
                            <span class="info-value">
                                <?php 
                                if (!empty($item['data_cadastro'])) {
                                    $date = new DateTime($item['data_cadastro']);
                                    echo $date->format('d/m/Y H:i');
                                } else {
                                    echo '---';
                                }
                                ?>
                            </span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">ID do Item:</span>
                            <span class="info-value">#<?php echo $item['id']; ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">ID do Usuário:</span>
                            <span class="info-value">#<?php echo $item['usuario_id']; ?></span>
                        </div>
                    </div>
                    
                    <!-- AÇÕES -->
                    <div class="info-section">
                        <h4><i class="fas fa-tools"></i> Ações</h4>
                        <div class="btn-group">
                            <a href="pesquisar_item.php" class="btn btn-secondary">
                                <i class="fas fa-arrow-left"></i> Voltar para Pesquisa
                            </a>
                            <a href="editar_item.php?id=<?php echo $itemId; ?>" class="btn btn-primary">
                                <i class="fas fa-edit"></i> Editar Item
                            </a>
                            <button onclick="confirmarExclusao(<?php echo $itemId; ?>)" class="btn btn-danger">
                                <i class="fas fa-trash"></i> Excluir Item
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
<script>
function confirmarExclusao(id) {
    if (confirm("Tem certeza que deseja excluir este item? Essa ação não pode ser desfeita.")) {
        window.location.href = "delete_item.php?id=" + id;
    }
}
</script>

    <!-- Modal de Confirmação de Exclusão -->
    <div id="modalExclusao" style="display: none; position: fixed;

    
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Collectify - Gerenciador de Coleções</title>
    <link rel="stylesheet" href="assets/css/estilos.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="logo">
                <i class="fas fa-compact-disc"></i>
                <h1>Collectify</h1>
            </div>
            <ul class="nav-links">
                <li><a href="index.html" class="active"><i class="fas fa-home"></i> Início</a></li>
                <li><a href="login.html"><i class="fas fa-sign-in-alt"></i> Login</a></li>
                <li><a href="#sobre"><i class="fas fa-info-circle"></i> Sobre</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section class="hero">
            <div class="hero-content">
                <h2>Organize sua coleção de mídias</h2>
                <p>CDs, LPs, BoxSets e muito mais em um só lugar</p>
                <a href="login.html" class="btn-primary">Começar Agora</a>
            </div>
        </section>

        <section class="features">
            <h2>Recursos Principais</h2>
            <div class="features-grid">
                <div class="feature-card">
                    <i class="fas fa-database"></i>
                    <h3>Cadastro Completo</h3>
                    <p>Armazene todos os detalhes dos seus itens</p>
                </div>
                <div class="feature-card">
                    <i class="fas fa-search"></i>
                    <h3>Busca Inteligente</h3>
                    <p>Encontre rapidamente qualquer item</p>
                </div>
                <div class="feature-card">
                    <i class="fas fa-images"></i>
                    <h3>Upload de Imagens</h3>
                    <p>Adicione fotos dos seus itens</p>
                </div>
                <div class="feature-card">
                    <i class="fas fa-heart"></i>
                    <h3>Lista de Desejos</h3>
                    <p>Guarde itens que você deseja adquirir</p>
                </div>
            </div>
        </section>

        <section id="sobre" class="about">
            <h2>Sobre o Collectify</h2>
            <p>Sistema desenvolvido para organização e gerenciamento de coleções de mídias físicas.</p>
            <p>Projeto interdisciplinar - 2° Desenvolvimento de Sistemas</p>
        </section>
    </main>

    <footer>
        <p>Collectify &copy; 2024 - Emilly, Kauan, Caio, Leonardo</p>
    </footer>

    <script src="assets/js/mensagens.js"></script>
</body>
</html>
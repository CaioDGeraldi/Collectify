<?php
// REMOVA ou COMENTE esta linha:
// session_start();

class Database {
    private $host = 'localhost';
    private $db_name = 'collectify_db';
    private $username = 'root';
    private $password = '';
    private $conn;

    public function getConnection() {
        $this->conn = null;

        try {
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name,
                $this->username,
                $this->password
            );
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->exec("set names utf8");
        } catch(PDOException $exception) {
            error_log("Erro de conexão: " . $exception->getMessage());
            return null;
        }

        return $this->conn;
    }
}



function verificarLoginAPI() {
    // Se não houver sessão ativa, inicia
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    // Verificar se usuário está logado
    if (!isset($_SESSION['usuario_id'])) {
        http_response_code(401);
        echo json_encode([
            'success' => false,
            'message' => 'Acesso não autorizado. Faça login primeiro.',
            'redirect' => 'login.php'
        ]);
        exit();
    }
}


function getConnection() {
    static $db = null;
    if ($db === null) {
        $database = new Database();
        $db = $database->getConnection();
    }
    return $db;
}
?>
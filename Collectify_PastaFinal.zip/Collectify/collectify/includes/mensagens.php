<?php

function mostrarMensagem($tipo = null, $mensagem = null) {
    if ($tipo && $mensagem) {
        $_SESSION[$tipo] = $mensagem;
    }
}

function exibirMensagens() {
    $html = '';
    
    if (isset($_SESSION['sucesso'])) {
        $html .= '<div class="mensagem sucesso">' . $_SESSION['sucesso'] . '</div>';
        unset($_SESSION['sucesso']);
    }
    
    if (isset($_SESSION['erro'])) {
        $html .= '<div class="mensagem erro">' . $_SESSION['erro'] . '</div>';
        unset($_SESSION['erro']);
    }
    
    if (isset($_SESSION['info'])) {
        $html .= '<div class="mensagem info">' . $_SESSION['info'] . '</div>';
        unset($_SESSION['info']);
    }
    
    return $html;
}
?>
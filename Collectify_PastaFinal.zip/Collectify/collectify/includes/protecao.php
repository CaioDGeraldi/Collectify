<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function verificarLogin() {
    if (!isset($_SESSION['usuario_id'])) {
        $_SESSION['erro'] = "Acesso negado. Faça login.";
        header("Location: login.html");
        exit();
    }
}

function isAdmin() {
    return isset($_SESSION['tipo_usuario']) && $_SESSION['tipo_usuario'] === 'admin';
}

function isVisitante() {
    return isset($_SESSION['tipo_usuario']) && $_SESSION['tipo_usuario'] === 'visitante';
}

// Somente ADMIN pode criar/editar/excluir
function protegerAdmin() {
    if (!isAdmin()) {
        $_SESSION['erro'] = "Apenas administradores podem acessar essa área.";
        header("Location: dashboard.php");
        exit();
    }
}
?>

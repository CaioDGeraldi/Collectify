<?php
require_once 'includes/protecao.php';
require_once 'includes/mensagens.php';
verificarLogin();

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Collectify</title>
    <link rel="stylesheet" href="assets/css/estilos.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="logo">
                <i class="fas fa-compact-disc"></i>
                <h1>Collectify</h1>
            </div>
            <div style="color: white;">
                Olá, <?php echo $_SESSION['usuario_nome']; ?>!
            </div>
            <ul class="nav-links">
                <li><a href="dashboard.php" class="active"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="minhas_colecoes.php"><i class="fas fa-folder"></i> Minhas Coleções</a></li>
                <li><a href="api/logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
            </ul>
        </nav>
    </header>

    <div class="dashboard-container">
        <aside class="sidebar">
            <ul>
                <li><a href="dashboard.php" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="cadastrar_item.php"><i class="fas fa-plus-circle"></i> Novo Item</a></li>
                <li><a href="pesquisar_item.php"><i class="fas fa-search"></i> Pesquisar</a></li>
                <li><a href="minhas_colecoes.php"><i class="fas fa-folder"></i> Minhas Coleções</a></li>
                <li><a href="lista_desejos.php"><i class="fas fa-heart"></i> Lista de Desejos</a></li>
                <?php if ($_SESSION['tipo_usuario'] === 'admin'): ?>
                <?php endif; ?>
            </ul>
        </aside>

        <main class="main-content">
            <h2><i class="fas fa-tachometer-alt"></i> Dashboard</h2>
            
            <?php echo exibirMensagens(); ?>
            
            <div class="dashboard-stats">
                <div class="stats-grid">
                    <div class="stat-card">
                        <i class="fas fa-compact-disc"></i>
                        <h3>Total de Itens</h3>
                        <p id="total-itens">0</p>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-heart"></i>
                        <h3>Lista de Desejos</h3>
                        <p id="total-desejos">0</p>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-folder"></i>
                        <h3>Coleções</h3>
                        <p id="total-colecoes">0</p>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-user"></i>
                        <h3>Último Login</h3>
                        <p><?php echo date('d/m/Y H:i'); ?></p>
                    </div>
                </div>
            </div>

            <h3 style="margin-top: 2rem;"><i class="fas fa-history"></i> Itens Recentes</h3>
            <div id="itens-recentes" class="itens-grid">
                <!-- Itens serão carregados via JavaScript -->
            </div>
        </main>
    </div>

    <script src="assets/js/mensagens.js"></script>
    <script src="assets/js/dashboard.js"></script>
</body>
</html>
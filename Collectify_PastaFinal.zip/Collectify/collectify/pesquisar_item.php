<?php
require_once 'includes/protecao.php';
require_once 'includes/mensagens.php';
verificarLogin();

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesquisar - Collectify</title>
    <link rel="stylesheet" href="assets/css/estilos.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="logo">
                <i class="fas fa-compact-disc"></i>
                <h1>Collectify</h1>
            </div>
            <ul class="nav-links">
                <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="pesquisar_item.php" class="active"><i class="fas fa-search"></i> Pesquisar</a></li>
                <li><a href="api/logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
            </ul>
        </nav>
    </header>

    <div class="dashboard-container">
        <aside class="sidebar">
            <ul>
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="cadastrar_item.php"><i class="fas fa-plus-circle"></i> Novo Item</a></li>
                <li><a href="pesquisar_item.php" class="active"><i class="fas fa-search"></i> Pesquisar</a></li>
                <li><a href="minhas_colecoes.php"><i class="fas fa-folder"></i> Minhas Coleções</a></li>
                <li><a href="lista_desejos.php"><i class="fas fa-heart"></i> Lista de Desejos</a></li>
            </ul>
        </aside>

        <main class="main-content">
            <h2><i class="fas fa-search"></i> Pesquisar Itens</h2>
            
            <?php echo exibirMensagens(); ?>
            
            <div class="form-container" style="max-width: 800px;">
                <form id="formPesquisa" onsubmit="pesquisarItens(event)">
                    <div class="form-group">
                        <label for="termo"><i class="fas fa-search"></i> Termo de Pesquisa:</label>
                        <input type="text" id="termo" name="termo" class="form-control" 
                               placeholder="Digite artista, álbum, gravadora...">
                    </div>
                    
                    <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                        <div class="form-group">
                            <label for="tipo_midia">Tipo de Mídia:</label>
                            <select id="tipo_midia" name="tipo_midia" class="form-control">
                                <option value="">Todos</option>
                                <option value="CD">CD</option>
                                <option value="LP">LP</option>
                                <option value="BoxSet">BoxSet</option>
                                <option value="Livro">Livro</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="ano_inicio">Ano (De - Até):</label>
                            <div style="display: flex; gap: 10px;">
                                <input type="number" id="ano_inicio" name="ano_inicio" 
                                       class="form-control" placeholder="De" min="1900" max="2024">
                                <input type="number" id="ano_fim" name="ano_fim" 
                                       class="form-control" placeholder="Até" min="1900" max="2024">
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Características:</label>
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px;">
                            <label style="display: flex; align-items: center; gap: 5px;">
                                <input type="checkbox" name="autografado" value="1">
                                <span>Autografado</span>
                            </label>
                            <label style="display: flex; align-items: center; gap: 5px;">
                                <input type="checkbox" name="primeira_edicao" value="1">
                                <span>Primeira Edição</span>
                            </label>
                            <label style="display: flex; align-items: center; gap: 5px;">
                                <input type="checkbox" name="importado" value="1">
                                <span>Importado</span>
                            </label>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn-primary">
                            <i class="fas fa-search"></i> Pesquisar
                        </button>
                        <button type="button" class="btn-secondary" onclick="limparFiltros()">
                            <i class="fas fa-times"></i> Limpar Filtros
                        </button>
                    </div>
                </form>
            </div>
            
            <div id="resultados-pesquisa" style="margin-top: 2rem;">
                <!-- Resultados serão carregados aqui -->
            </div>
        </main>
    </div>

    <script src="assets/js/mensagens.js"></script>
<script>
    // Garantir que a função está disponível globalmente
    function limparFiltros() {
        if (typeof window.limparFiltros === 'function') {
            window.limparFiltros();
        } else {
            document.getElementById('formPesquisa').reset();
            document.getElementById('resultados-pesquisa').innerHTML = '';
        }
    }
</script>
<script src="assets/js/filtros_pesquisa.js"></script>
</body>
</html>
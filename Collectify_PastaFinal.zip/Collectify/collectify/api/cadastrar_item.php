<?php
// api/cadastrar_item.php - Versão corrigida

// Incluir configurações
require_once '../includes/conexao.php';
require_once '../includes/protecao.php';
require_once '../includes/mensagens.php';

// Verificar sessão apenas se não estiver ativa
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.html');
    exit();
}

// Verificar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['erro'] = 'Método de requisição não permitido.';
    header('Location: ../cadastrar_item.php');
    exit();
}

// Obter conexão com banco
$conn = getConnection();
if (!$conn) {
    $_SESSION['erro'] = 'Erro de conexão com o banco de dados.';
    header('Location: ../cadastrar_item.php');
    exit();
}

try {
    // Verificar campos obrigatórios
    $camposObrigatorios = ['artista_banda', 'nome', 'ano_lancamento', 'tipo_midia'];
    $erros = [];
    
    foreach ($camposObrigatorios as $campo) {
        if (empty($_POST[$campo])) {
            $erros[] = "Campo obrigatório não preenchido: $campo";
        }
    }
    
    if (!empty($erros)) {
        $_SESSION['erro'] = implode('<br>', $erros);
        header('Location: ../cadastrar_item.php');
        exit();
    }
    
    // Processar upload de imagem
    $nomeImagem = null;
    if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] === UPLOAD_ERR_OK) {
        $extensao = strtolower(pathinfo($_FILES['imagem']['name'], PATHINFO_EXTENSION));
        $extensoesPermitidas = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        
        if (in_array($extensao, $extensoesPermitidas)) {
            // Validar tamanho da imagem (máximo 5MB)
            if ($_FILES['imagem']['size'] > 5242880) {
                $_SESSION['erro'] = 'A imagem é muito grande. Tamanho máximo: 5MB.';
                header('Location: ../cadastrar_item.php');
                exit();
            }
            
            $nomeImagem = uniqid() . '.' . $extensao;
            $caminhoDestino = '../assets/uploads/' . $nomeImagem;
            
            // Criar pasta uploads se não existir
            if (!is_dir('../assets/uploads')) {
                mkdir('../assets/uploads', 0755, true);
            }
            
            // Mover arquivo para a pasta de uploads
            if (!move_uploaded_file($_FILES['imagem']['tmp_name'], $caminhoDestino)) {
                error_log("Erro ao mover arquivo uploadado: " . $_FILES['imagem']['error']);
                $_SESSION['alerta'] = 'Imagem não foi salva, mas o item foi cadastrado.';
            }
        } else {
            $_SESSION['alerta'] = 'Formato de imagem não suportado. Formatos permitidos: JPG, PNG, GIF, WebP.';
        }
    }
    
    // === ADICIONE ESTA PARTE ===
    // Processar imagem da URL (se veio da Discogs)
    if (empty($nomeImagem) && !empty($_POST['imagem_url'])) {
        $imagem_url = filter_var($_POST['imagem_url'], FILTER_VALIDATE_URL);
        
        if ($imagem_url) {
            try {
                // Baixar imagem da URL
                $image_data = file_get_contents($imagem_url);
                if ($image_data !== false) {
                    // Determinar extensão
                    $headers = get_headers($imagem_url, 1);
                    $content_type = isset($headers['Content-Type']) ? $headers['Content-Type'] : '';
                    
                    if (strpos($content_type, 'image/jpeg') !== false) {
                        $extensao = 'jpg';
                    } elseif (strpos($content_type, 'image/png') !== false) {
                        $extensao = 'png';
                    } elseif (strpos($content_type, 'image/gif') !== false) {
                        $extensao = 'gif';
                    } elseif (strpos($content_type, 'image/webp') !== false) {
                        $extensao = 'webp';
                    } else {
                        // Tentar deduzir pela URL
                        $url_path = parse_url($imagem_url, PHP_URL_PATH);
                        $url_ext = pathinfo($url_path, PATHINFO_EXTENSION);
                        $extensao = in_array(strtolower($url_ext), ['jpg', 'jpeg', 'png', 'gif', 'webp']) ? $url_ext : 'jpg';
                    }
                    
                    $nomeImagem = uniqid() . '.' . $extensao;
                    $caminhoDestino = '../assets/uploads/' . $nomeImagem;
                    
                    // Criar pasta uploads se não existir
                    if (!is_dir('../assets/uploads')) {
                        mkdir('../assets/uploads', 0755, true);
                    }
                    
                    // Salvar imagem
                    if (file_put_contents($caminhoDestino, $image_data)) {
                        $_SESSION['info'] = 'Imagem baixada da Discogs com sucesso!';
                    } else {
                        error_log("Erro ao salvar imagem da URL: $imagem_url");
                    }
                }
            } catch (Exception $e) {
                error_log("Erro ao baixar imagem da URL: " . $e->getMessage());
            }
        }
    }
    // === FIM DA PARTE ADICIONAL ===
    
    // Preparar dados para inserção
    $dados = [
        'usuario_id' => $_SESSION['usuario_id'],
        'artista_banda' => trim($_POST['artista_banda']),
        'nome' => trim($_POST['nome']),
        'ano_lancamento' => intval($_POST['ano_lancamento']),
        'tipo_midia' => $_POST['tipo_midia'],
        'gravadora' => !empty($_POST['gravadora']) ? trim($_POST['gravadora']) : null,
        'origem' => !empty($_POST['origem']) ? trim($_POST['origem']) : null,
        'qualidade' => !empty($_POST['qualidade']) ? trim($_POST['qualidade']) : null,
        'edicao' => !empty($_POST['edicao']) ? trim($_POST['edicao']) : null,
        'encarte' => isset($_POST['encarte']) ? 1 : 0,
        'obi_coa' => isset($_POST['obi_coa']) ? 1 : 0,
        'hypersticker' => isset($_POST['hypersticker']) ? 1 : 0,
        'boxset' => isset($_POST['boxset']) ? 1 : 0,
        'autografado' => isset($_POST['autografado']) ? 1 : 0,
        'primeira_edicao' => isset($_POST['primeira_edicao']) ? 1 : 0,
        'limitado' => isset($_POST['limitado']) ? 1 : 0,
        'importado' => isset($_POST['importado']) ? 1 : 0,
        'observacoes' => !empty($_POST['observacoes']) ? trim($_POST['observacoes']) : null,
        'imagem' => $nomeImagem
    ];
    
    $query = "INSERT INTO itens (";
    $query .= implode(', ', array_keys($dados));
    $query .= ") VALUES (";
    $query .= ':' . implode(', :', array_keys($dados));
    $query .= ")";
    
    // Preparar e executar a query
    $stmt = $conn->prepare($query);
    
    foreach ($dados as $key => $value) {
        $stmt->bindValue(":$key", $value);
    }
    
    if ($stmt->execute()) {
        // Obter ID do item inserido
        $item_id = $conn->lastInsertId();
        
        // Log da atividade
        error_log("Item cadastrado - ID: $item_id, Usuário: {$_SESSION['usuario_id']}");
        
        // Adicionar mensagem de sucesso na sessão
        $_SESSION['sucesso'] = '✅ Item cadastrado com sucesso!';
        
        // Se houver coleção selecionada, adicionar o item à coleção
        if (!empty($_POST['colecao_id'])) {
            try {
                $query_colecao = "INSERT INTO itens_colecao (item_id, colecao_id) VALUES (:item_id, :colecao_id)";
                $stmt_colecao = $conn->prepare($query_colecao);
                $stmt_colecao->execute([
                    ':item_id' => $item_id,
                    ':colecao_id' => $_POST['colecao_id']
                ]);
                $_SESSION['info'] = 'Item também foi adicionado à coleção selecionada.';
            } catch (Exception $e) {
                error_log("Erro ao adicionar item à coleção: " . $e->getMessage());
            }
        }
        
        // Redirecionar para o dashboard
        header('Location: ../dashboard.php');
        exit();
        
    } else {
        $_SESSION['erro'] = '❌ Erro ao cadastrar item no banco de dados.';
        header('Location: ../cadastrar_item.php');
        exit();
    }
    
} catch(PDOException $exception) {
    error_log("Erro ao cadastrar item: " . $exception->getMessage());
    $_SESSION['erro'] = '❌ Erro no servidor: ' . $exception->getMessage();
    header('Location: ../cadastrar_item.php');
    exit();
}

// Fechar conexão
$conn = null;
?>
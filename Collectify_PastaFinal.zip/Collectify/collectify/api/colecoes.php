<?php
// api/colecoes.php - VERSÃO SIMPLIFICADA

// Desligar exibição de erros
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);

// Iniciar sessão
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Retornar JSON
header('Content-Type: application/json; charset=utf-8');

// Verificar login
if (!isset($_SESSION['usuario_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit();
}

require_once '../includes/conexao.php';

try {
    $conn = getConnection();
    if (!$conn) {
        throw new Exception('Erro de conexão');
    }
    
    $admin_id = 1; // ID do administrador
$usuario_id = $admin_id;
    
    // Buscar coleções
    $stmt = $conn->prepare("
        SELECT c.*, COUNT(ic.item_id) as total_itens 
        FROM colecoes c 
        LEFT JOIN itens_colecao ic ON c.id = ic.colecao_id 
        WHERE c.usuario_id = ? 
        GROUP BY c.id 
        ORDER BY c.nome ASC
    ");
    
    $stmt->execute([$usuario_id]);
    $colecoes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'colecoes' => $colecoes
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erro: ' . $e->getMessage()]);
}
?>
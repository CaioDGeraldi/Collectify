<?php
// api/discogs_detalhes.php - Obter detalhes de um release específico

header('Content-Type: application/json; charset=utf-8');

// Configurações
$discogs_token = 'EyyEUoxAbZVThrFhNTvaviVfXwdYlgDTZUhvlYSV';
$user_agent = 'Collectify/1.0 +http://localhost/collectify';

// Verificar ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'ID do release é obrigatório'
    ]);
    exit();
}

$release_id = intval($_GET['id']);

// URL da API Discogs para detalhes do release
$url = "https://api.discogs.com/releases/{$release_id}";

// Configurar requisição
$options = [
    'http' => [
        'method' => 'GET',
        'header' => [
            "Authorization: Discogs token={$discogs_token}",
            "User-Agent: {$user_agent}",
            "Accept: application/json"
        ]
    ]
];

$context = stream_context_create($options);

try {
    // Fazer requisição
    $response = file_get_contents($url, false, $context);
    
    if ($response === FALSE) {
        throw new Exception('Erro ao acessar API Discogs');
    }
    
    $data = json_decode($response, true);
    
    // Extrair informações relevantes
    $detalhes = [
        'id' => $data['id'] ?? null,
        'title' => $data['title'] ?? null,
        'artists' => isset($data['artists']) ? array_map(function($artist) {
            return $artist['name'] ?? 'Desconhecido';
        }, $data['artists']) : null,
        'artist' => isset($data['artists'][0]['name']) ? $data['artists'][0]['name'] : null,
        'year' => $data['year'] ?? null,
        'labels' => $data['labels'] ?? null,
        'label' => isset($data['labels'][0]['name']) ? $data['labels'][0]['name'] : null,
        'formats' => $data['formats'] ?? null,
        'format' => isset($data['formats'][0]['name']) ? $data['formats'][0]['name'] : null,
        'genres' => $data['genres'] ?? null,
        'genre' => isset($data['genres']) ? implode(', ', $data['genres']) : null,
        'styles' => $data['styles'] ?? null,
        'style' => isset($data['styles']) ? implode(', ', $data['styles']) : null,
        'tracklist' => $data['tracklist'] ?? null,
        'notes' => $data['notes'] ?? null,
        'cover_image' => $data['images'][0]['uri'] ?? ($data['cover_image'] ?? null),
        'resource_url' => $data['uri'] ?? null
    ];
    
    echo json_encode([
        'success' => true,
        'detalhes' => $detalhes
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao carregar detalhes: ' . $e->getMessage()
    ]);
}
?>
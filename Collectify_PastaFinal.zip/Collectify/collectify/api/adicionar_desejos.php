<?php
// api/adicionar_desejos.php - DESABILITAR ERROS
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);

require_once '../includes/conexao.php';
require_once '../includes/protecao.php';

// Não iniciar sessão aqui - já foi iniciada em protecao.php
// REMOVA: session_start();

verificarLogin();

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit();
}

$conn = getConnection();
if (!$conn) {
    echo json_encode(['success' => false, 'message' => 'Erro de conexão com o banco']);
    exit();
}

try {
    $usuarioId = $_SESSION['usuario_id'];
    $itemId = $_POST['item_id'] ?? null;
    
    if (!$itemId) {
        echo json_encode(['success' => false, 'message' => 'ID do item não informado']);
        exit();
    }
    
    // Verificar se o item pertence ao usuário
    $stmt = $conn->prepare("SELECT id FROM itens WHERE id = ? AND usuario_id = ?");
    $stmt->execute([$itemId, $usuarioId]);
    
    if ($stmt->rowCount() === 0) {
        echo json_encode(['success' => false, 'message' => 'Item não encontrado']);
        exit();
    }
    
    // Verificar se já está na lista de desejos
    $stmt = $conn->prepare("SELECT * FROM lista_desejos WHERE usuario_id = ? AND item_id = ?");
    $stmt->execute([$usuarioId, $itemId]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => false, 'message' => 'Item já está na lista de desejos']);
        exit();
    }
    
    // Adicionar à lista de desejos
    $stmt = $conn->prepare("INSERT INTO lista_desejos (usuario_id, item_id, data_adicao) VALUES (?, ?, NOW())");
    
    if ($stmt->execute([$usuarioId, $itemId])) {
        echo json_encode(['success' => true, 'message' => 'Item adicionado à lista de desejos']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Erro ao adicionar item']);
    }
    
} catch(PDOException $exception) {
    error_log("Erro ao adicionar desejo: " . $exception->getMessage());
    echo json_encode(['success' => false, 'message' => 'Erro no servidor']);
}
?>
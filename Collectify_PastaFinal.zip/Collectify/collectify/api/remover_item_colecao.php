<?php
// api/remover_item_colecao.php - VERSÃO CORRIGIDA
error_reporting(0);
ini_set('display_errors', 0);

require_once '../includes/conexao.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit();
}

$userId = $_SESSION['usuario_id'];

// Obter dados
$input = file_get_contents('php://input');
parse_str($input, $data);

if (!isset($data['item_id']) || !isset($data['colecao_id'])) {
    echo json_encode(['success' => false, 'message' => 'Parâmetros inválidos']);
    exit();
}

$itemId = intval($data['item_id']);
$colecaoId = intval($data['colecao_id']);

$pdo = getConnection();
if (!$pdo) {
    echo json_encode(['success' => false, 'message' => 'Erro de conexão']);
    exit();
}

try {
    // Verificar se a coleção pertence ao usuário
    $stmt = $pdo->prepare("SELECT id FROM colecoes WHERE id = ? AND usuario_id = ?");
    $stmt->execute([$colecaoId, $userId]);
    
    if ($stmt->rowCount() === 0) {
        echo json_encode(['success' => false, 'message' => 'Coleção não encontrada']);
        exit();
    }
    
    // Remover da coleção (CORRIGIDO - não precisa de 'id')
    $stmt = $pdo->prepare("DELETE FROM itens_colecao WHERE item_id = ? AND colecao_id = ?");
    $stmt->execute([$itemId, $colecaoId]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode([
            'success' => true,
            'message' => '✅ Item removido da coleção!'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Item não encontrado na coleção']);
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Erro: ' . $e->getMessage()]);
}
?>
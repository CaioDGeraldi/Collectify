<?php
// api/pesquisar.php - VERSÃO FINAL COM IMAGEM
require_once __DIR__ . '/../includes/conexao.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit();
}

$admin_id = 1; // ID do administrador
$usuario_id = $admin_id;
$pdo = getConnection();

if (!$pdo) {
    echo json_encode(['success' => false, 'message' => 'Erro no banco']);
    exit();
}

// COLETAR FILTROS
$where = "WHERE usuario_id = :user_id";
$params = [':user_id' => $userId];

if (isset($_GET['termo']) && !empty($_GET['termo'])) {
    $where .= " AND (artista_banda LIKE :termo OR nome LIKE :termo OR gravadora LIKE :termo)";
    $params[':termo'] = '%' . $_GET['termo'] . '%';
}

if (isset($_GET['tipo_midia']) && !empty($_GET['tipo_midia'])) {
    $where .= " AND tipo_midia = :tipo";
    $params[':tipo'] = $_GET['tipo_midia'];
}

if (isset($_GET['autografado']) && $_GET['autografado'] == '1') {
    $where .= " AND autografado = 1";
}

if (isset($_GET['primeira_edicao']) && $_GET['primeira_edicao'] == '1') {
    $where .= " AND primeira_edicao = 1";
}

if (isset($_GET['importado']) && $_GET['importado'] == '1') {
    $where .= " AND importado = 1";
}

if (isset($_GET['ano_inicio']) && !empty($_GET['ano_inicio'])) {
    $where .= " AND ano_lancamento >= :ano_inicio";
    $params[':ano_inicio'] = intval($_GET['ano_inicio']);
}

if (isset($_GET['ano_fim']) && !empty($_GET['ano_fim'])) {
    $where .= " AND ano_lancamento <= :ano_fim";
    $params[':ano_fim'] = intval($_GET['ano_fim']);
}

// BUSCAR COM TODOS OS CAMPOS IMPORTANTES
try {
    $sql = "SELECT 
                id,
                artista_banda,
                nome,
                ano_lancamento,
                tipo_midia,
                gravadora,
                imagem,
                autografado,
                primeira_edicao,
                importado,
                limitado,
                encarte,
                codigo
            FROM itens $where 
            ORDER BY artista_banda, ano_lancamento DESC 
            LIMIT 100";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $itens = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'itens' => $itens,
        'total' => count($itens)
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Erro: ' . $e->getMessage()
    ]);
}
?>
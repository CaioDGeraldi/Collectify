<?php
// api/buscar_itens_colecao.php - VERSÃO CORRIGIDA
error_reporting(0);
ini_set('display_errors', 0);

require_once '../includes/conexao.php';
require_once '../includes/protecao.php';

verificarLogin();

header('Content-Type: application/json; charset=utf-8');

// Verificar parâmetros
if (!isset($_GET['colecao_id']) || !is_numeric($_GET['colecao_id'])) {
    echo json_encode(['success' => false, 'message' => 'ID da coleção inválido']);
    exit();
}

$colecao_id = intval($_GET['colecao_id']);
$usuario_id = $_SESSION['usuario_id'];
$termo = isset($_GET['q']) ? trim($_GET['q']) : '';

try {
    $conn = getConnection();
    if (!$conn) {
        throw new Exception('Erro de conexão com o banco');
    }
    
    // Buscar itens que NÃO estão na coleção (CORRIGIDO)
    $sql = "SELECT i.* FROM itens i 
            WHERE i.usuario_id = ? 
            AND i.id NOT IN (
                SELECT ic.item_id 
                FROM itens_colecao ic 
                WHERE ic.colecao_id = ?
            )";
    
    $params = [$usuario_id, $colecao_id];
    
    if (!empty($termo)) {
        $sql .= " AND (i.nome LIKE ? OR i.artista_banda LIKE ? OR i.gravadora LIKE ?)";
        $searchTerm = "%$termo%";
        $params[] = $searchTerm;
        $params[] = $searchTerm;
        $params[] = $searchTerm;
    }
    
    $sql .= " ORDER BY i.artista_banda, i.nome ASC";
    
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    
    $itens = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'itens' => $itens,
        'total' => count($itens)
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'Erro ao buscar itens'
    ]);
}
?>
// assets/js/filtros_pesquisa.js - VERSÃO COM IMAGENS
async function pesquisarItens(event) {
    if (event) event.preventDefault();
    
    console.log('🔍 Pesquisando...');
    
    // Mostrar loading
    const resultadosDiv = document.getElementById('resultados-pesquisa');
    resultadosDiv.innerHTML = `
        <div style="text-align: center; padding: 2rem;">
            <i class="fas fa-spinner fa-spin fa-2x"></i>
            <p>Carregando...</p>
        </div>
    `;
    
    // Coletar dados do formulário
    const formData = new FormData(document.getElementById('formPesquisa'));
    const params = new URLSearchParams();
    
    for (const [key, value] of formData.entries()) {
        if (value) params.append(key, value);
    }
    
    // Checkboxes
    ['autografado', 'primeira_edicao', 'importado'].forEach(name => {
        const checkbox = document.querySelector(`[name="${name}"]`);
        if (checkbox && checkbox.checked) {
            params.append(name, '1');
        }
    });
    
    // Fazer requisição
    try {
        const response = await fetch(`api/pesquisar.php?${params}`);
        const data = await response.json();
        
        console.log('Dados:', data);
        exibirResultadosComImagens(data);
        
    } catch (error) {
        console.error('Erro:', error);
        resultadosDiv.innerHTML = `<p style="color:red;">Erro: ${error.message}</p>`;
    }
}

function exibirResultadosComImagens(data) {
    const container = document.getElementById('resultados-pesquisa');
    
    if (data.success && data.itens && data.itens.length > 0) {
        let html = `
            <div style="margin-bottom: 2rem;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                    <h3 style="margin: 0; color: #2c3e50;">
                        <i class="fas fa-search"></i> Resultados
                        <span style="background: #3498db; color: white; padding: 2px 8px; border-radius: 12px; font-size: 0.9rem; margin-left: 8px;">
                            ${data.total} ${data.total === 1 ? 'item' : 'itens'}
                        </span>
                    </h3>
                </div>
                
                <div class="itens-grid">
        `;
        
        // Para cada item, criar card com imagem
        data.itens.forEach(item => {
            // Determinar cor da borda baseado no tipo de mídia
            let borderColor = '#3498db'; // Azul padrão
            if (item.tipo_midia === 'LP') borderColor = '#e74c3c'; // Vermelho para LP
            if (item.tipo_midia === 'CD') borderColor = '#2ecc71'; // Verde para CD
            if (item.tipo_midia === 'BoxSet') borderColor = '#9b59b6'; // Roxo para BoxSet
            if (item.tipo_midia === 'Livro') borderColor = '#f39c12'; // Laranja para Livro
            
            // URL da imagem - CORRIGINDO O CAMINHO
            let imagemUrl = '';
            if (item.imagem) {
                // Se a imagem já tem caminho completo
                if (item.imagem.includes('http') || item.imagem.includes('assets/')) {
                    imagemUrl = item.imagem;
                } else {
                    // Se é apenas o nome do arquivo
                    imagemUrl = `assets/uploads/${item.imagem}`;
                }
            }
            
            // Ícones de características
            let caracteristicasHTML = '';
            if (item.autografado == 1) caracteristicasHTML += '<span title="Autografado" style="color:#e74c3c;margin-right:5px;">✍️</span>';
            if (item.primeira_edicao == 1) caracteristicasHTML += '<span title="Primeira Edição" style="color:#f39c12;margin-right:5px;">⭐</span>';
            if (item.importado == 1) caracteristicasHTML += '<span title="Importado" style="color:#3498db;margin-right:5px;">🌎</span>';
            
            html += `
                <div class="item-card" style="border: 2px solid ${borderColor};">
                    <div class="item-image" style="height: 180px; overflow: hidden; background: #f8f9fa; display: flex; align-items: center; justify-content: center;">
            `;
            
            if (imagemUrl) {
                html += `
                    <img src="${imagemUrl}" 
                         alt="${item.nome}"
                         style="width: 100%; height: 100%; object-fit: cover;"
                         onerror="this.src='assets/img/default-album.jpg'; this.onerror=null;">
                `;
            } else {
                html += `
                    <div style="text-align: center; color: #666; padding: 1rem;">
                        <i class="fas fa-compact-disc" style="font-size: 3rem;"></i>
                        <p style="margin-top: 0.5rem; font-size: 0.9rem;">Sem imagem</p>
                    </div>
                `;
            }
            
            html += `
                    </div>
                    <div class="item-info" style="padding: 1rem;">
                        <div style="margin-bottom: 0.5rem;">
                            ${caracteristicasHTML}
                        </div>
                        <h3 style="margin: 0 0 0.5rem 0; font-size: 1.1rem; color: #2c3e50;">
                            ${escapeHtml(item.nome || 'Sem nome')}
                        </h3>
                        <p style="margin: 0 0 0.5rem 0; color: #7f8c8d; font-weight: 500;">
                            ${escapeHtml(item.artista_banda || 'Artista desconhecido')}
                        </p>
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                            <span style="background: #ecf0f1; padding: 3px 8px; border-radius: 4px; font-size: 0.85rem;">
                                ${item.ano_lancamento || 'N/A'}
                            </span>
                            <span style="background: ${borderColor}; color: white; padding: 3px 8px; border-radius: 4px; font-size: 0.85rem;">
                                ${item.tipo_midia || '---'}
                            </span>
                        </div>
                        <div style="margin-top: 1rem; display: flex; gap: 8px;">
                            <button onclick="verDetalhes(${item.id})" 
                                    style="flex: 1; padding: 8px; background: #2ecc71; color: white; border: none; border-radius: 4px; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 5px;">
                                <i class="fas fa-eye"></i> Ver
                            </button>
                            <button onclick="adicionarDesejo(${item.id})" 
                                    style="flex: 1; padding: 8px; background: #e74c3c; color: white; border: none; border-radius: 4px; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 5px;">
                                <i class="fas fa-heart"></i> Desejo
                            </button>
                        </div>
                    </div>
                </div>
            `;
        });
        
        html += `
                </div>
            </div>
        `;
        
        container.innerHTML = html;
        
    } else {
        container.innerHTML = `
            <div style="text-align: center; padding: 3rem; color: #666;">
                <i class="fas fa-search fa-3x" style="margin-bottom: 1rem;"></i>
                <h3>Nenhum item encontrado</h3>
                <p>Tente alterar os critérios de busca.</p>
            </div>
        `;
    }
}

// Função para escapar HTML
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Função para ver detalhes
function verDetalhes(itemId) {
    window.location.href = `detalhes_item.php?id=${itemId}`;
}

// Função para adicionar à lista de desejos - VERSÃO CORRIGIDA
async function adicionarDesejo(itemId) {
    console.log('❤️ Adicionando item', itemId, 'aos favoritos');
    
    // Mostrar loading no botão
    const button = event.target;
    const originalHTML = button.innerHTML;
    button.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
    button.disabled = true;
    
    try {
        const response = await fetch('api/adicionar_desejos.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `item_id=${itemId}`
        });
        
        console.log('📥 Status:', response.status);
        
        const data = await response.json();
        console.log('✅ Resposta:', data);
        
        // Restaurar botão
        button.innerHTML = originalHTML;
        button.disabled = false;
        
        if (data.success) {
            // Sucesso - usar sistema de mensagens se existir
            if (typeof mostrarMensagem === 'function') {
                mostrarMensagem('sucesso', data.message || '✅ Item adicionado aos favoritos!');
            } else {
                // Se não tem sistema de mensagens, mostrar alerta bonito
                showToast('success', data.message || '✅ Item adicionado aos favoritos!');
            }
            
            // Opcional: mudar ícone do botão para confirmar
            button.innerHTML = '<i class="fas fa-check"></i> Adicionado';
            button.style.background = '#27ae60';
            button.disabled = true;
            
            // Voltar ao estado normal após 3 segundos
            setTimeout(() => {
                button.innerHTML = originalHTML;
                button.style.background = '';
                button.disabled = false;
            }, 3000);
            
        } else {
            // Erro - mostrar mensagem
            if (typeof mostrarMensagem === 'function') {
                mostrarMensagem('erro', data.message || '❌ Erro ao adicionar aos favoritos');
            } else {
                showToast('error', data.message || '❌ Erro ao adicionar aos favoritos');
            }
        }
        
    } catch (error) {
        console.error('❌ Erro na adição:', error);
        
        // Restaurar botão
        button.innerHTML = originalHTML;
        button.disabled = false;
        
        // Erro de conexão
        if (typeof mostrarMensagem === 'function') {
            mostrarMensagem('erro', '❌ Erro de conexão');
        } else {
            showToast('error', '❌ Erro de conexão');
        }
    }
}

// Função auxiliar para mostrar toasts (se não tiver sistema de mensagens)
function showToast(type, message) {
    // Criar elemento toast
    const toast = document.createElement('div');
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 12px 20px;
        border-radius: 8px;
        color: white;
        font-weight: 500;
        z-index: 9999;
        animation: slideIn 0.3s ease-out;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        min-width: 300px;
        max-width: 400px;
    `;
    
    if (type === 'success') {
        toast.style.background = 'linear-gradient(135deg, #27ae60, #2ecc71)';
    } else {
        toast.style.background = 'linear-gradient(135deg, #e74c3c, #c0392b)';
    }
    
    toast.innerHTML = `
        <div style="display: flex; align-items: center; gap: 10px;">
            <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}" 
               style="font-size: 1.2rem;"></i>
            <span>${message}</span>
        </div>
    `;
    
    // Adicionar ao body
    document.body.appendChild(toast);
    
    // Remover após 4 segundos
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease-in';
        setTimeout(() => {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 300);
    }, 4000);
    
    // Adicionar animações CSS se não existirem
    if (!document.querySelector('#toast-animations')) {
        const style = document.createElement('style');
        style.id = 'toast-animations';
        style.textContent = `
            @keyframes slideIn {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            @keyframes slideOut {
                from {
                    transform: translateX(0);
                    opacity: 1;
                }
                to {
                    transform: translateX(100%);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);
    }
}

// Função para verificar se item já está nos favoritos (opcional)
async function verificarSeEstaNosFavoritos(itemId) {
    try {
        const response = await fetch('api/lista_desejos.php');
        const data = await response.json();
        
        if (data.success && data.itens) {
            return data.itens.some(item => item.id == itemId);
        }
        return false;
    } catch (error) {
        console.error('Erro ao verificar favoritos:', error);
        return false;
    }
}
function limparFiltros() {
    document.getElementById('formPesquisa').reset();
    document.getElementById('resultados-pesquisa').innerHTML = '';
}

// Inicializar
document.addEventListener('DOMContentLoaded', function() {
    console.log('Pesquisa carregada');
});
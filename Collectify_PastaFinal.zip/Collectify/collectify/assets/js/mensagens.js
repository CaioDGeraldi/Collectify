function mostrarMensagem(tipo, texto, duracao = 5000) {
    // Remover mensagens existentes
    const mensagensExistentes = document.querySelectorAll('.mensagem-flutuante');
    mensagensExistentes.forEach(msg => msg.remove());
    
    // Criar nova mensagem
    const mensagemDiv = document.createElement('div');
    mensagemDiv.className = `mensagem-flutuante ${tipo}`;
    mensagemDiv.innerHTML = `
        <span>${texto}</span>
        <button onclick="this.parentElement.remove()">&times;</button>
    `;
    
    // Estilos para mensagem flutuante
    mensagemDiv.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem;
        border-radius: 4px;
        color: white;
        display: flex;
        align-items: center;
        justify-content: space-between;
        min-width: 300px;
        max-width: 500px;
        z-index: 10000;
        animation: slideIn 0.3s ease-out;
        box-shadow: 0 2px 10px rgba(0,0,0,0.2);
    `;
    
    if (tipo === 'sucesso') {
        mensagemDiv.style.backgroundColor = '#155724';
    } else if (tipo === 'erro') {
        mensagemDiv.style.backgroundColor = '#721c24';
    } else if (tipo === 'info') {
        mensagemDiv.style.backgroundColor = '#0c5460';
    }
    
    document.body.appendChild(mensagemDiv);
    
    // Remover automaticamente após duração
    setTimeout(() => {
        if (mensagemDiv.parentElement) {
            mensagemDiv.style.animation = 'slideOut 0.3s ease-in';
            setTimeout(() => mensagemDiv.remove(), 300);
        }
    }, duracao);
    
    // Adicionar CSS para animações
    if (!document.getElementById('mensagem-animations')) {
        const style = document.createElement('style');
        style.id = 'mensagem-animations';
        style.textContent = `
            @keyframes slideIn {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            @keyframes slideOut {
                from {
                    transform: translateX(0);
                    opacity: 1;
                }
                to {
                    transform: translateX(100%);
                    opacity: 0;
                }
            }
            .mensagem-flutuante button {
                background: none;
                border: none;
                color: white;
                font-size: 1.5rem;
                cursor: pointer;
                margin-left: 10px;
            }
        `;
        document.head.appendChild(style);
    }
}

// Verificar mensagens na sessionStorage (para páginas recarregadas)
document.addEventListener('DOMContentLoaded', function() {
    const mensagem = sessionStorage.getItem('mensagem_flutuante');
    const tipo = sessionStorage.getItem('mensagem_tipo');
    
    if (mensagem && tipo) {
        mostrarMensagem(tipo, mensagem);
        sessionStorage.removeItem('mensagem_flutuante');
        sessionStorage.removeItem('mensagem_tipo');
    }
});